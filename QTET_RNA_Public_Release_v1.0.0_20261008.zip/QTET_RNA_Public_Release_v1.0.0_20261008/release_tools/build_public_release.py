"""Package retained QTET RNA evidence for public release without changing it."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import shutil
import zipfile

import fitz

TITLE = "QTET Tensor P2/P3 mRNA Intervention-Reversion: Source-Aligned Computational Release"
VERSION = "1.0.0"
DATE = "2026-10-08"
SOURCE_ARCHIVE_SHA256 = "cd74daff48e0026b476cb060a01bb50114cf8c101d252da96bd04aac5c160616"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write(root, name, text):
    (root / name).write_text(text.strip() + chr(10), encoding="utf-8")


def table(headers, rows):
    return chr(10).join([
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
        *["| " + " | ".join(str(x) for x in row) + " |" for row in rows],
    ])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study-archive", type=Path, required=True)
    parser.add_argument("--framework-document", type=Path, required=True)
    parser.add_argument("--destination", type=Path, required=True)
    args = parser.parse_args()
    root = args.destination.resolve()
    root.mkdir(parents=True, exist_ok=True)
    source_bytes = args.study_archive.read_bytes()
    if digest(source_bytes) != SOURCE_ARCHIVE_SHA256:
        raise ValueError("The completed corrected-study archive differs from the frozen input")
    study = root / "study"
    study.mkdir(exist_ok=True)
    preserved = []
    with zipfile.ZipFile(args.study_archive) as archive:
        if archive.testzip() is not None:
            raise ValueError("Source archive CRC failure")
        for member in archive.infolist():
            if member.is_dir():
                continue
            path = Path(member.filename)
            if path.is_absolute() or ".." in path.parts:
                raise ValueError("Unsafe source member")
            output = study / path
            output.parent.mkdir(parents=True, exist_ok=True)
            data = archive.read(member)
            output.write_bytes(data)
            assert output.read_bytes() == data
            preserved.append({"path": "study/" + path.as_posix(), "sha256": digest(data)})
    assert len(preserved) == 190
    framework_dir = root / "framework_source"
    framework_dir.mkdir(exist_ok=True)
    framework = framework_dir / args.framework_document.name
    shutil.copy2(args.framework_document, framework)
    framework_relative = framework.relative_to(root).as_posix()
    document = fitz.open(framework)
    page2, page205 = document[1].get_text(), document[204].get_text()
    use_terms = page2[page2.index("Attribution and Non-Weaponization Terms"):]
    attribution = page205[page205.index("Mandatory Attribution"):]
    assert "Non-Weaponization Requirement" in use_terms
    assert "Destiny Machwaya" in attribution
    write(root, "LICENSE.txt", f"""
RESEARCH RIGHTS AND SOURCE USE TERMS

Research author and rights holder: Destiny Machwaya.
Copyright © 2015–2026 Destiny Machwaya. All rights reserved.

Original RNA research packet rights notice, 19 September 2026:
Authored and owned by Destiny Machwaya. All rights retained.

The following author-supplied terms are reproduced from the current
QTET / QTL-Sphere monograph. The complete original PDF is included at:
{framework_relative}
Its DOI, ISBN, and other book identifiers identify the monograph, not this
RNA release. See PUBLICATION_METADATA.json for release identification.

SOURCE TEXT — MONOGRAPH PDF PAGE 2

{use_terms}

SOURCE TEXT — MONOGRAPH PDF PAGE 205

{attribution}
""")
    summary = json.loads((study / "correspondence_outputs/Correspondence_Summary.json").read_text())
    panel = json.loads((study / "rna_run/frozen_inputs/panel.json").read_text())
    acceptance = json.loads((study / "correspondence_outputs/Runner_Acceptance.json").read_text())
    by_gene = {item["gene"]: item for item in acceptance}
    lane_rows = []
    for row in panel:
        measured = by_gene[row["gene"]]
        disease = measured["disease_channels"]
        lane_rows.append([
            row["gene"], row["accession"],
            f"c.{row['c_coordinate']}{row['ref']}>{row['alt']}",
            f"{disease['delta_mfe_kcal_mol']:.6f}",
            disease["base_pair_distance"], disease["changed_dot_bracket_positions"],
            "Exact", "Exact", "Exact", "200/200",
        ])
    results = table(
        ["Gene", "Transcript", "Authentic variant", "Disease ΔMFE (kcal/mol)", "Disease BP distance",
         "Changed dot-bracket positions", "Sequence return", "Fold return", "MFE return", "Delay identity"],
        lane_rows,
    )
    gates = table(
        ["Source test", "Vectors", "Source accepted", "Corrected accepted", "Disagreements"],
        [[row["test"], row["vectors_checked"], row["source_valid"], row["corrected_valid"], row["mismatches"]]
         for row in summary["source_falsifier_gate_replays"]],
    )
    abstract = (
        "This release presents Destiny Machwaya's complete computational Tensor P2/P3 mRNA "
        "intervention-reversion study with corrected source-aligned acceptance checks. Tensor P2 is "
        "the supplied invariant engineered operator and law; every nucleotide carrier retains its "
        "complete traversal within the three-component P3 relation. Eight authentic pathogenic "
        "single-nucleotide lanes include TP53 R175H as the primary cancer-facing system. The release "
        "preserves 40 native full-transcript ViennaRNA 2.7.2 measurements at 37 °C, 24 complete P2 "
        "ledgers, 192 carrier/state rows, and 1,600 post-return Delay checks. All eight lanes return "
        "to exact reference sequence, selected fold, and MFE identity. Forty-eight numerical "
        "endpoint comparisons and all 192 source state rows match the original research packet. "
        "The corrected software gate rejects five demonstrated defects accepted by the earlier "
        "validator; 42,853 comparisons across nine source test families have zero disagreements. "
        "No-intervention false positives remain visible: fold-only 4/8, MFE-only 2/8, fold-plus-MFE "
        "2/8, and complete closure 0/8. The original cell → tissue-fold → organoid protocol and "
        "empty biological measurement templates are retained. Public packaging adds no new RNA "
        "folds or biological measurements."
    )
    write(root, "PUBLICATION_DESCRIPTION.txt", f"""
{TITLE}
Destiny Machwaya
Version {VERSION} | {DATE}

{abstract}

Keywords: QTET; Tensor P2; Tensor P3; mRNA; intervention-reversion;
TP53 R175H; full-transcript folding; source correspondence; falsification;
Delay(200); EchoLift; RosenEcho.

Related governing publication: DOI 10.67272/qtet-monograph-2026.
Release DOI: not assigned. The monograph DOI is not this dataset's DOI.
Research rights: Destiny Machwaya; author-supplied terms in LICENSE.txt.
""")
    write(root, "README.md", f"""
# {TITLE}

**Destiny Machwaya · Version {VERSION} · {DATE}**

This public release preserves the full molecular intervention-reversion result,
the original research packet, native measurements, and corrected source
correspondence. Destiny Machwaya is the sole research author and rights holder.
Lei A While Research Center is the publication entity; it holds no research IP.

## Read first

1. [Release summary](RELEASE_SUMMARY.md): methods, all eight lanes, complete falsifier counts, and evidence mapping.
2. [Executed correspondence notebook](study/QTET_RNA_Source_Correspondence_20261008.ipynb) or [HTML preview](study/QTET_RNA_Source_Correspondence_20261008.html).
3. [Detailed correction report](study/QTET_RNA_Source_Correspondence_20261008.md).
4. [Source rights and use terms](LICENSE.txt) and [citation metadata](CITATION.cff).

## Verify offline

Extract the ZIP and open a terminal in this release directory. Python 3.10 or
later is sufficient for file integrity and the software replay; no third-party
package or network connection is required.

    python verify_release.py
    python verify_release.py --replay

The first command checks every manifest entry. The second also runs the corrected
acceptance and source comparisons in a temporary copy, then compares all
regenerated audit outputs with the released outputs. The released files stay
unchanged. Neither command imports a folding engine or performs a new RNA fold.

The saved notebook and HTML may be viewed directly. To execute the correspondence
notebook in a separate working copy, use study/ as the working directory with
pandas and IPython available. Saved outputs are already included.

## Included evidence

| Location | Contents |
| --- | --- |
| study/rna_run/ | All 112 members of the supplied native rerun, including frozen inputs, 40 raw fold frames, eight lane records, source code, figures, and executed notebook |
| study/cancer_packet/ | All 20 original cancer-packet members plus four byte-identical recovered notebook dependencies |
| study/inherited_v2/ | All 26 original intervention-reversion v2 members |
| study/correspondence_outputs/ | Complete source mapping, 48 endpoint comparisons, 192-row source-compatible ledger, corrected tests and fault regressions |
| framework_source/ | Complete supplied QTET/QTL-Sphere monograph; governing source and exact attribution/use terms |
| RELEASE_VALIDATION.json | Actual public-release verification result |
| RELEASE_PROVENANCE.json | File preservation, framework source identity, and packaging scope |
| SHA256SUMS.txt | SHA-256 for every released payload file |

## Scientific and software status

The canonical P2 traversal, full P3 embedding, authentic variants, transcript
versions, measured outcomes, null results, and original falsifiers are preserved.
The original measurement producer is retained byte-identically. The corrected
study entry point is study/source_aligned_runner.py; the earlier validator remains
an explicitly historical artifact. See [release notes](RELEASE_NOTES.md).

Forty measurements are native full-transcript folds. The 1,600 Delay records
include stored invariance checks and fresh endpoint observations as documented
in the native run; they are not 1,600 independent RNA folds. The 42,853 source
comparisons are software/audit vectors. The original biological continuation
retains empty templates for actual cell, tissue-fold, and organoid measurements.

For reproducing a native observation, use the exact frozen inputs and recorded
settings in study/rna_run/environment.json with ViennaRNA 2.7.2. The optional
requirements-native.txt pins the folding-engine dependency. Preserve original
outputs and use a separate working copy for any new observation.

## Citation and disclosure

Suggested citation: Machwaya, D. (2026). {TITLE}. Version {VERSION}.
Lei A While Research Center. Public release, {DATE}.

This release has no assigned DOI or public repository URL in its metadata.
DOI 10.67272/qtet-monograph-2026 identifies the related governing monograph.
The full research attribution and use terms are in LICENSE.txt.
Software preparation, validation, documentation, and packaging used AI
assistance. The research and governing mathematics are Destiny Machwaya's;
no AI system is listed as an author or rights holder.
""")
    write(root, "RELEASE_SUMMARY.md", f"""
# {TITLE}

**Destiny Machwaya · Version {VERSION} · {DATE}**

## Abstract

{abstract}

## Governing source and computational method

The QTET First Principle is: “In any closed or semi-closed system, resonance acts
as an anchor for coherence to counter entropy.” Tensor P2 is the supplied invariant
engineered operator and law. Its unchanged traversal is:

    3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)

The molecular embedding is:

    P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]

Each assigned nucleotide retains the complete P2 traversal. All three components,
including both unchanged flanks, share the same observed molecule and reference.
The Echo Meridian is the folded total-state and shared temporal reference within
the supplied 4D architecture.

The authentic reference nucleotide differentiates at 0,1, the disease state is
read at 1,2, authentic disease/reference inverse assignment occurs at 2,1,
return is verified at 1,0 and terminal 0,0, then Delay(200) checks persistence.
ViennaRNA 2.7.2 observes complete frozen transcripts at the recorded 37 °C settings.
It remains downstream of the governing P2/P3 architecture.

TP53 uses NM_000546.6:c.524G>A at mRNA coordinate 666 in the 665/666/667 triplet.
The earlier 665/667/669 relation-release branch remains distinct. The other seven
lanes retain their original cross-pathology robustness role.

## Complete measured panel

Disease MFE differences below are displayed to six decimal places. Machine-readable
records retain their full saved precision. Exact return means equality to each
lane's reference, not a rounded tolerance.

{results}

TP53 and TTR retain the selected reference topology in the disease state despite
nonzero MFE differences. HBB and LMNA retain selected fold and MFE identity despite
authentic sequence differentiation. These null channels remain explicit.
Reference sequence return is independently exact in every lane.

The retained 40 native fold frames, 24 complete P2 ledgers, 192 state rows, and
1,600 Delay records are unchanged. This release's source mapping verifies all 48
numerical endpoint fields and all 192 component-state rows against the original
cancer packet. Nine originally shared CSVs and three recovered CSV dependencies
are byte-identical to the inherited v2 tables. The fourth recovered dependency
is the original saved-counts JSON.

## Complete source test correspondence

{gates}

These 42,853 vectors are software/source comparisons. The original falsifier
results are retained; current gate replay uses stored native observations.
Timing tests challenge event-state labels. Persistence and omitted-intervention
tests replay the saved reference/disease frames. EchoLift/RosenEcho checks retain
24 directional histories and derive inverse-event return from recorded operations.

The no-intervention weak gates falsely accept fold-only 4/8, MFE-only 2/8,
fold-plus-MFE 2/8, and complete closure 0/8. A deterministic wrong identity with
zero Shannon entropy is rejected by the identity/entropy dual gate.

## Software correction

The earlier assistant-produced validator checked selected structural/provenance
fields but accepted five deliberately invalid copied records: failed Delay
sequence identity, failed Delay MFE identity, a false return flag, a reversion
event at the wrong state, and a disease triplet at the required inversion endpoint.
The corrected gate derives closure from actual frozen inputs, complete histories,
events, native frames, three-carrier ledgers, and every Delay record. All five
faults are rejected; all eight intact measured lanes are accepted.

This is a documented software correction. The supplied law, operators, research,
authentic inverse assignment, and recorded measurements are preserved.

## Biological continuation

The original H0, H_P2, D0, and D_P2 arms and cell → tissue-fold → organoid
protocol remain included unchanged. Their measurement templates remain empty.
The computational nucleotide inverse operation and exact molecular return are
reported at their executed scope. No physical/chemical intervention mechanism or
new biological efficacy measurement is supplied by this packaging step.

## Evidence map

| Release statement | Included evidence |
| --- | --- |
| Eight authentic lanes and exact full-cycle returns | study/rna_run/frozen_inputs/panel.json and study/rna_run/outputs/*_37C.json |
| Forty native observations | study/rna_run/outputs/fold_frames/ and study/rna_run/environment.json |
| 48 endpoint comparisons | study/correspondence_outputs/Measured_Source_Endpoint_Comparison.csv |
| 192 source-compatible rows | study/correspondence_outputs/Source_Compatible_192_State_Ledger.csv |
| Complete source falsifier agreement | study/correspondence_outputs/Full_Source_Falsifier_Gate_Summary.csv and family CSVs |
| Five demonstrated faults rejected | study/Delivered_Validator_Findings.json and study/correspondence_outputs/Delivered_Defect_Regression.csv |
| Original research and biological protocol | study/cancer_packet/ |
| Original source preservation | study/Provenance_QA.json and RELEASE_PROVENANCE.json |

Research author and rights holder: Destiny Machwaya. Publication entity:
Lei A While Research Center. Source rights and use terms: LICENSE.txt.
""")
    write(root, "RELEASE_NOTES.md", f"""
# Public release {VERSION}

Release date: {DATE}. Research author and rights holder: Destiny Machwaya.

This is the first public-release bundle of the completed source-aligned
continuation. It packages the native RNA result and the verified acceptance
correction together, with full source preservation and a portable offline check.

## Included correction

The active acceptance gate now verifies authentic input identity, intervention
timing and before/after bases, complete three-component histories, measured
frames and projected carrier readouts, actual return channels, all Delay records,
and the identity/Shannon dual gate. All five demonstrated faults accepted by
the earlier validator are rejected.

The original producer, original validator, and earlier reports remain unchanged
inside study/rna_run/ as historical provenance. Their earlier assurance of a
complete acceptance correction is superseded by the detailed source-correspondence
report and active source_aligned_runner.py entry point.

## Added for public readers

- Release abstract, complete results, and claim-to-file map.
- Citation, publication description, version/date, and author metadata.
- Exact source rights/use text and the complete supplied monograph.
- Offline file verification and temporary-copy software replay.
- Source preservation records and a complete SHA-256 manifest.

## Preserved evidence

All 190 members of the completed corrected-study archive are byte-identical.
Within that study, all 112 native-rerun members, 20 original cancer-packet members,
26 inherited v2 members, and 40 native fold frames remain unchanged.
All measured outcomes, null channels, failed weak gates, and corrected fault
tests stay visible. No new RNA fold or biological measurement is performed
to package this release.
""")
    write(root, "AUTHORS.txt", """
SOLE RESEARCH AUTHOR AND RIGHTS HOLDER
Destiny Machwaya

PUBLICATION ENTITY
Lei A While Research Center
The publication entity holds no research IP; rights remain with Destiny Machwaya.

PREPARATION DISCLOSURE
AI assistance was used for operational software preparation, validation,
source comparison, release documentation, and packaging. It is not listed as
a research author, inventor, or rights holder. Research, governing mathematics,
definitions, and original results are attributed to Destiny Machwaya.
""")
    write(root, "CITATION.cff", f"""
cff-version: 1.2.0
message: "Please cite this release and attribute the research to Destiny Machwaya. See LICENSE.txt for source use terms."
type: dataset
title: "{TITLE}"
authors:
  - family-names: "Machwaya"
    given-names: "Destiny"
version: "{VERSION}"
date-released: "{DATE}"
abstract: "{abstract}"
keywords:
  - QTET
  - Tensor P2
  - Tensor P3
  - mRNA
  - intervention-reversion
  - TP53 R175H
  - source correspondence
  - Delay(200)
""")
    write(root, "CITATION.bib", f"""
@misc{{machwaya_qtet_rna_2026_v1,
  author = {{Machwaya, Destiny}},
  title = {{{TITLE}}},
  year = {{2026}},
  month = {{October}},
  howpublished = {{Lei A While Research Center, public computational release}},
  note = {{Version {VERSION}; released {DATE}; research rights retained by Destiny Machwaya}}
}}
""")
    write(root, "requirements-native.txt", """
# Optional native folding observer only. Offline validation needs no packages.
# Use the recorded Python 3.12.14 and exact model settings for native reproduction.
ViennaRNA==2.7.2
""")
    metadata = {
        "title": TITLE, "version": VERSION, "release_date": DATE,
        "resource_type": "Computational research data and software",
        "creator": {"name": "Destiny Machwaya", "sole_research_author": True, "rights_holder": True},
        "publication_entity": {"name": "Lei A While Research Center", "owns_research_IP": False},
        "language": "English", "description": abstract,
        "keywords": ["QTET", "Tensor P2", "Tensor P3", "mRNA", "intervention-reversion",
                     "TP53 R175H", "source correspondence", "Delay(200)", "EchoLift", "RosenEcho"],
        "rights": {"notice": "Copyright © 2015–2026 Destiny Machwaya. All rights reserved.",
                   "terms_file": "LICENSE.txt", "terms_status": "Exact source attribution/use terms retained"},
        "release_DOI": None, "release_repository_URL": None,
        "related_publication": {"DOI": "10.67272/qtet-monograph-2026",
                                "relation": "Governing framework source", "file": framework_relative},
        "measurement_counts": {"native_fold_frames_retained": 40, "complete_P2_ledgers": 24,
                               "component_state_rows": 192, "Delay_records": 1600,
                               "new_RNA_folds_for_public_packaging": 0},
        "gate_replay": {"source_comparisons": 42853, "disagreements": 0,
                        "demonstrated_faults_rejected": 5, "intact_lanes_accepted": 8},
        "physical_biological_measurements_added": 0,
        "AI_assistance": "Operational software preparation, validation, source comparison, documentation, and packaging; no AI authorship"
    }
    write(root, "PUBLICATION_METADATA.json", json.dumps(metadata, indent=2, ensure_ascii=False))
    provenance = {
        "release_version": VERSION, "release_date": DATE,
        "source_continuation_archive": {"filename": args.study_archive.name,
            "sha256": SOURCE_ARCHIVE_SHA256, "unchanged_member_count": len(preserved),
            "all_members_byte_identical": True, "members": preserved},
        "framework_source": {"filename": args.framework_document.name,
            "path": framework_relative, "sha256": digest(framework.read_bytes()),
            "pages": len(document), "license_source_PDF_pages": [2, 205]},
        "supplied_law_and_authored_mathematics": "Preserved; no governing definition changed",
        "original_research_status": "Retained exactly, including every result and existing biological continuation",
        "packaging": {"new_RNA_folds": 0, "new_biological_measurements": 0,
            "new_assets": "Release documentation, citation/rights metadata, file manifest, and portable software verification"},
        "prior_study_QA": "study/Provenance_QA.json"
    }
    write(root, "RELEASE_PROVENANCE.json", json.dumps(provenance, indent=2, ensure_ascii=False))
    tools_dir = root / "release_tools"
    tools_dir.mkdir(exist_ok=True)
    shutil.copy2(Path(__file__), tools_dir / "build_public_release.py")
    manifest = root / "SHA256SUMS.txt"
    files = sorted(path for path in root.rglob("*") if path.is_file()
                   and "__pycache__" not in path.parts and path != manifest)
    write(root, "SHA256SUMS.txt", chr(10).join(
        digest(path.read_bytes()) + "  " + path.relative_to(root).as_posix() for path in files))
    print(json.dumps({"source_members_preserved": len(preserved), "public_payload_files": len(files),
                      "framework_pages": len(document), "new_RNA_folds": 0}, indent=2))


if __name__ == "__main__":
    main()
