"""Apply the cancer packet's disclosed molecular history and closure criteria.

This validates the declared computational embodiment. It does not redefine
Tensor P2/P3, the Echo Meridian, or any authored governing mathematics.
"""
import hashlib
import math
from functools import lru_cache

STATES = ("3,3", "0,0:first", "0,1", "1,2", "2,1", "1,0", "0,0:final", "Delay(200)")


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def check_architecture(order, components):
    # Delay is the source's final log position, not an additional P2 state.
    require(tuple(order) == STATES, "Complete canonical P2 order, including post-return Delay, required")
    require(tuple(components) == (1, 2, 3), "All three complete P2 components required")
    return True


@lru_cache(maxsize=64)
def parse_structure(structure):
    stack, pairs, partners = [], set(), [0] * (len(structure) + 1)
    for position, symbol in enumerate(structure, 1):
        if symbol == "(":
            stack.append(position)
        elif symbol == ")":
            require(bool(stack), "Unbalanced measured fold")
            start = stack.pop()
            pairs.add((start, position))
            partners[start], partners[position] = position, start
        else:
            require(symbol == ".", "Unexpected measured fold symbol")
    require(not stack, "Unbalanced measured fold")
    return frozenset(pairs), tuple(partners)


def measured_channels(frame, reference, sequence, origin):
    pairs, _ = parse_structure(frame["structure"])
    ref_pairs, _ = parse_structure(reference["structure"])
    return {
        "sequence_hamming_full_transcript": sum(a != b for a, b in zip(sequence, origin)),
        "delta_mfe_kcal_mol": frame["mfe_kcal_mol"] - reference["mfe_kcal_mol"],
        "base_pair_distance": len(pairs.symmetric_difference(ref_pairs)),
        "changed_dot_bracket_positions": sum(a != b for a, b in zip(frame["structure"], reference["structure"])),
        "sequence_identity": sequence == origin,
        "fold_identity": frame["structure"] == reference["structure"],
        "mfe_identity": frame["mfe_kcal_mol"] == reference["mfe_kcal_mol"],
    }


def delay_identity_gate(sequence_hashes, reference_hash):
    reference_count = sum(x == reference_hash for x in sequence_hashes)
    other_count = len(sequence_hashes) - reference_count
    entropy = -sum((count / len(sequence_hashes)) * math.log2(count / len(sequence_hashes))
                   for count in (reference_count, other_count) if count)
    identity = len(sequence_hashes) == 200 and reference_count == 200
    return {"reference_checks": reference_count, "disease_or_nonreference_checks": other_count,
            "H_Shannon_bits_reference_vs_other": entropy,
            "entropy_zero": entropy == 0, "all_200_reference_identity": identity,
            "lawful_delay_closure": identity and entropy == 0}


def equal_channels(stored, measured, label):
    for key, value in measured.items():
        require(key in stored and stored[key] == value, f"{label}: {key} disagrees with measured data")


def validate_lane(record, reference_rna, expected_input):
    """Reject incorrect histories, identities, raw observations, or pass flags."""
    states = record["state_records"]
    require(record["canonical_tensor_p2"] == "3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)",
            "Recorded Tensor P2 differs from supplied source")
    require(record["canonical_tensor_p3"] == "P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]",
            "Recorded Tensor P3 differs from supplied source")
    check_architecture([s["state"] for s in states], (1, 2, 3))
    require(record["input"] == expected_input, "Run input differs from frozen source input")
    require(sha(reference_rna) == expected_input["reference_rna_sha256"], "Frozen reference RNA hash differs")
    require(len(reference_rna) == expected_input["length_nt"], "Frozen transcript length differs")
    origin = reference_rna.replace("U", "T")
    positions = expected_input["mrna_positions"]
    center = positions[1] - 1
    require(origin[center] == expected_input["ref"], "Authentic source base differs")
    disease = origin[:center] + expected_input["alt"] + origin[center + 1:]
    expected_sequences = [origin, origin, disease, disease, origin, origin, origin, origin]
    hashes = [sha(s.replace("T", "U")) for s in expected_sequences]
    frames_list = record["fold_measurements"]
    frames = {f["frame_id"]: f for f in frames_list}
    require(len(frames_list) == len(frames) == 5, "This run requires five distinct fresh fold records")
    reference = frames[states[1]["fold_frame_id"]]
    require(reference["sequence_rna_sha256"] == hashes[1], "Reference measurement input differs")
    for frame in frames_list:
        require(frame["full_transcript_length"] == len(origin), "Measured frame transcript length differs")
        require(len(frame["structure"]) == len(origin), "Measured fold has incorrect transcript length")
        require(sha(frame["structure"]) == frame["dot_bracket_sha256"], "Measured fold hash differs")
        require(frame["temperature_C"] == record["temperature_C"] == 37.0, "Source baseline temperature differs")
        require(frame["engine"] == "ViennaRNA 2.7.2", "Source observer version differs")
        require(math.isfinite(frame["mfe_kcal_mol"]), "Nonfinite measured MFE")
        parse_structure(frame["structure"])
    events = record["events"]
    for index in (0, 2, 4):
        require(frames[states[index]["fold_frame_id"]]["state"] == STATES[index],
                "Fresh entry, differentiation, and return measurement provenance required")
    require(len(events) == 8, "Complete event history required")
    ledger = record["P3_component_ledger"]
    require(len(ledger) == 24, "All three full P2 ledgers required")
    for index, (state, sequence, event) in enumerate(zip(states, expected_sequences, events)):
        require(state["state_index"] == index, "Incorrect state index")
        require(event["state"] == STATES[index], "Molecular intervention event occurs at wrong P2 state")
        require(event["sequence_rna_sha256"] == hashes[index], "Event molecular state differs from source history")
        require(event["reference_epoch"] == state["reference_epoch"] == hashes[1], "Shared source reference differs")
        require(event["all_three_complete_prefixes"] is True, "Event lacks complete three-component prefixes")
        if index in (2, 4):
            before, after = ((expected_input["ref"], expected_input["alt"]) if index == 2
                             else (expected_input["alt"], expected_input["ref"]))
            require(event.get("coordinate") == positions[1] and event.get("before") == before
                    and event.get("after") == after, "Authentic differentiation/inversion pair differs")
        else:
            require(event["operation"] == "retain shared molecular state", "Unexpected molecular operation")
        require(state["sequence_rna_sha256"] == hashes[index], "Disease hold, inversion, or return identity fails")
        require(state["triplet"] == "".join(sequence[p - 1] for p in positions), "Observed P3 bases differ")
        frame = frames[state["fold_frame_id"]]
        require(frame["sequence_rna_sha256"] == hashes[index], "Observer input detached from source molecular state")
        require(state["dot_bracket_sha256"] == frame["dot_bracket_sha256"]
                and state["mfe_kcal_mol"] == frame["mfe_kcal_mol"], "State readout differs from measured frame")
        _, partners = parse_structure(frame["structure"])
        require(state["component_partners"] == [partners[p] for p in positions], "Observed P3 partners differ")
        require(state["all_three_synchronized"] is True, "Unsynchronized P3 state")
        component_rows = [r for r in ledger if r["state_index"] == index]
        check_architecture(STATES, [r["component_index"] for r in component_rows])
        for component, row in enumerate(component_rows, 1):
            coordinate = positions[component - 1]
            require(row["P3_component"] == f"P2_{component} ⊗ D_{component}", "P3 dimensional embedding differs")
            require(row["mrna_coordinate"] == coordinate and row["coding_coordinate"]
                    == expected_input["c_coordinate"] + component - 2, "Carrier coordinate differs")
            require(row["state"] == STATES[index] and row["complete_P2_prefix_length"] == index + 1
                    and row["all_three_synchronized"] is True, "Incomplete component history")
            require(row["base"] == sequence[coordinate - 1] and row["reference_base"] == origin[coordinate - 1]
                    and row["RNA_partner_coordinate"] == partners[coordinate], "Carrier molecular observation differs")
            require(row["shared_molecule_sequence_rna_sha256"] == hashes[index]
                    and row["shared_fold_frame_id"] == frame["frame_id"]
                    and row["shared_dot_bracket_sha256"] == frame["dot_bracket_sha256"]
                    and row["shared_reference_epoch"] == hashes[1], "Carrier readout detached from shared molecule")
        if index >= 1:
            equal_channels(state["comparison_to_reference"], measured_channels(frame, reference, sequence, origin),
                           f"State {STATES[index]}")
    disease_frame = frames[states[3]["fold_frame_id"]]
    return_frame = frames[states[7]["fold_frame_id"]]
    disease_channels = measured_channels(disease_frame, reference, disease, origin)
    return_channels = measured_channels(return_frame, reference, origin, origin)
    equal_channels(record["disease_measurement"], disease_channels, "Disease summary")
    equal_channels(record["returned_measurement"], return_channels, "Return summary")
    require(return_channels["sequence_identity"] and return_channels["fold_identity"]
            and return_channels["mfe_identity"], "Measured return identity fails")
    delay = record["delay_records"]
    require(len(delay) == 200, "Complete Delay(200) records required")
    for number, check in enumerate(delay, 1):
        require(check["iteration"] == number, "Delay iteration missing or reordered")
        require(check["sequence_rna_sha256"] == hashes[1], "Nonreference molecular state during Delay")
        frame = frames[check["fold_frame_id"]]
        require(frame["sequence_rna_sha256"] == check["sequence_rna_sha256"], "Delay observer input detached")
        require(check["dot_bracket_sha256"] == frame["dot_bracket_sha256"]
                and check["mfe_kcal_mol"] == frame["mfe_kcal_mol"], "Delay readout differs from measured frame")
        equal_channels(check, measured_channels(frame, reference, origin, origin), f"Delay check {number}")
        require(check["sequence_identity"] is True and check["fold_identity"] is True
                and check["mfe_identity"] is True, "Delay identity or measured-energy failure")
        require(check["reference_epoch"] == hashes[1] and check["all_three_P2_complete"] is True
                and check["coordinates_invariant"] is True, "Delay lacks invariant complete P3")
        _, partners = parse_structure(frame["structure"])
        require(check["carrier_bases"] == [origin[p - 1] for p in positions]
                and check["carrier_partners"] == [partners[p] for p in positions], "Delay carrier observation differs")
    require(frames[delay[0]["fold_frame_id"]]["state"] == "Delay(200):1"
            and frames[delay[-1]["fold_frame_id"]]["state"] == "Delay(200):200", "Fresh Delay endpoint frames required")
    dual_gate = delay_identity_gate([c["sequence_rna_sha256"] for c in delay], hashes[1])
    require(dual_gate["lawful_delay_closure"], "Delay Shannon and identity dual gate fails")
    derived_validation = {"complete_P2P3": True, "canonical_history": True,
                          "sequence_return": return_channels["sequence_identity"],
                          "fold_return": return_channels["fold_identity"],
                          "mfe_return": return_channels["mfe_identity"],
                          "Delay200": dual_gate["lawful_delay_closure"]}
    require(record["validation"] == derived_validation, "Reported pass flags differ from derived closure criteria")
    return {"gene": expected_input["gene"], "closure_pass": all(derived_validation.values()),
            "complete_P2_ledgers": 3, "component_state_rows": len(ledger), "Delay_checks": len(delay),
            "disease_channels": disease_channels, "return_channels": return_channels, "delay_dual_gate": dual_gate}
