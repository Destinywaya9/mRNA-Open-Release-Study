# QTET RNA reversion source correspondence continuation

Research author and rights holder: Destiny Machwaya. Supplied law and mathematics preserved.

Start with QTET_RNA_Source_Correspondence_20261008.md. The continuation corrects a demonstrated acceptance-gate defect in the assistant-produced rerun. It preserves all native measurements and all original source artifacts. The earlier validator is retained in rna_run/ as the unchanged producer/provenance record; use source_aligned_runner.py as the corrected entry point.

`python source_aligned_runner.py` validates all eight retained lanes against the full disclosed source criteria before accepting cached results. `python verify_source_correspondence.py` compares the complete source tables and replays the source falsifier vectors. Neither repeats RNA folds with the included data. Only the explicit --execute-missing option can execute a missing originally authorized baseline lane.

The executed correspondence notebook and HTML contain the full comparison, demonstrated defects, complete falsifier counts, and exact source mapping. Original native observations and their executed notebook remain in rna_run/. The complete cancer packet is preserved in cancer_packet/ with four previously archived dependencies added to its continuation copy. All inherited v2 files remain in inherited_v2/. Original attached archive hashes and per-file preservation checks are recorded in Provenance_QA.json. SHA256SUMS.txt records the completed package.

The supplied molecular intervention definition is preserved. Original preclinical templates remain empty; no biological results are generated. No source research artifact or original recorded result is overwritten.
