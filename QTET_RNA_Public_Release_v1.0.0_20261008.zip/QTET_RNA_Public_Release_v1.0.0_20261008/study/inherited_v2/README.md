# QTET mRNA Full P2/P3 Intervention-Reversion Assault v2

This package supersedes the prior disease-state-centered heavy assault.

Primary executed source: `QTET_mRNA_Cross_Pathology_Panel_v1 (1).ipynb`.

The package makes the complete P2/P3 intervention cycle explicit for all eight authentic pathogenic variants, including three complete P2 ledgers per P3 relation, intervention reversion at `2,1`, return verification, final `0,0`, and Delay(200).

The executed audit notebook uses saved results from the source notebook and does not require ViennaRNA locally. `QTET_mRNA_Full_P2P3_Intervention_Colab_v3.ipynb` is provided to re-run the fold engine in Colab with ViennaRNA.
