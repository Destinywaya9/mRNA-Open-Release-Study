"""Independently reconcile RNA inputs, partner maps, histories, and summaries."""
from pathlib import Path
import csv
import hashlib
import json
import math


def sha(text):
    return hashlib.sha256(text.encode()).hexdigest()


def pairs(structure):
    stack, result, partners = [], set(), [0]*(len(structure)+1)
    for position, symbol in enumerate(structure, 1):
        if symbol == "(":
            stack.append(position)
        elif symbol == ")":
            start = stack.pop()
            result.add((start, position))
            partners[start], partners[position] = position, start
        elif symbol != ".":
            raise ValueError("Unexpected dot-bracket symbol")
    assert not stack
    return result, partners


def main(root=None):
    root = Path(root or Path(__file__).resolve().parent)
    inputs = json.loads((root/"frozen_inputs/panel.json").read_text())
    source = {r["gene"]:r for r in csv.DictReader((root/"source_inspection/Source_Executed_Cross_Pathology_Results.csv").open())}
    expected_states = ["3,3", "0,0:first", "0,1", "1,2", "2,1", "1,0", "0,0:final", "Delay(200)"]
    report, reconciliations = [], []
    for row in inputs:
        gene = row["gene"]
        r = json.loads((root/"outputs"/f"{gene}_37C.json").read_text())
        origin = "".join(x for x in (root/"frozen_inputs"/f"{row['accession']}.reference.fasta").read_text().splitlines() if not x.startswith(">"))
        assert sha(origin) == row["reference_rna_sha256"]
        assert hashlib.sha256((root/"frozen_inputs"/row["genbank_file"]).read_bytes()).hexdigest() == row["genbank_sha256"]
        dna = origin.replace("U", "T")
        assert [s["state"] for s in r["state_records"]] == expected_states
        assert len(r["P3_component_ledger"]) == 24
        frames = {f["frame_id"]:f for f in r["fold_measurements"]}
        assert len(frames) == 5
        reference = frames[r["state_records"][1]["fold_frame_id"]]
        reference_pairs, _ = pairs(reference["structure"])
        current = dna
        disease_sequence = None
        for index, state in enumerate(r["state_records"]):
            if index == 2:
                center = row["mrna_positions"][1]-1
                assert current[center] == row["ref"]
                current = current[:center]+row["alt"]+current[center+1:]
                disease_sequence = current
            if index == 4:
                assert current[center] == row["alt"]
                current = current[:center]+dna[center]+current[center+1:]
            assert sha(current.replace("T","U")) == state["sequence_rna_sha256"]
            frame = frames[state["fold_frame_id"]]
            assert frame["sequence_rna_sha256"] == state["sequence_rna_sha256"]
            assert sha(frame["structure"]) == state["dot_bracket_sha256"]
            frame_pairs, partners = pairs(frame["structure"])
            component_rows = [x for x in r["P3_component_ledger"] if x["state_index"] == index]
            assert [x["component_index"] for x in component_rows] == [1,2,3]
            for component, entry in enumerate(component_rows):
                coordinate = row["mrna_positions"][component]
                assert entry["mrna_coordinate"] == coordinate
                assert entry["base"] == current[coordinate-1]
                assert entry["RNA_partner_coordinate"] == partners[coordinate]
                assert entry["shared_molecule_sequence_rna_sha256"] == state["sequence_rna_sha256"]
                assert entry["shared_fold_frame_id"] == state["fold_frame_id"]
                assert entry["complete_P2_prefix_length"] == index+1
            if "comparison_to_reference" in state:
                measured = state["comparison_to_reference"]
                assert measured["delta_mfe_kcal_mol"] == frame["mfe_kcal_mol"]-reference["mfe_kcal_mol"]
                assert measured["base_pair_distance"] == len(frame_pairs.symmetric_difference(reference_pairs))
                assert measured["sequence_hamming_full_transcript"] == sum(a!=b for a,b in zip(current,dna))
        assert disease_sequence != dna and current == dna
        assert len(r["delay_records"]) == 200
        for number, check in enumerate(r["delay_records"],1):
            assert check["iteration"] == number and check["all_three_P2_complete"]
            assert check["sequence_rna_sha256"] == sha(origin)
            assert check["sequence_identity"] and check["fold_identity"] and check["mfe_identity"]
            frame = frames[check["fold_frame_id"]]
            assert check["dot_bracket_sha256"] == sha(frame["structure"])
            assert check["mfe_kcal_mol"] == frame["mfe_kcal_mol"]
        old = source[gene]
        disease = r["disease_measurement"]
        disease_frame = frames[r["state_records"][3]["fold_frame_id"]]
        comparison = {
            "reference_energy_matches_source_at_recorded_precision": round(reference["mfe_kcal_mol"],6)==float(old["reference_mfe_kcal_mol"]),
            "disease_energy_matches_source_at_recorded_precision": round(disease_frame["mfe_kcal_mol"],6)==float(old["differentiated_mfe_kcal_mol"]),
            "disease_delta_matches_source_at_recorded_precision": round(disease["delta_mfe_kcal_mol"],6)==float(old["delta_mfe_kcal_mol"]),
            "disease_bp_distance_matches_source": disease["base_pair_distance"]==int(old["base_pair_distance"]),
            "disease_changed_positions_match_source": disease["changed_dot_bracket_positions"]==int(old["changed_dot_bracket_positions"]),
        }
        reconciliations.append({"gene":gene,**comparison})
        identity_counts = {True:0, False:0}
        for check in r["delay_records"]: identity_counts[check["sequence_identity"]]+=1
        entropy = -sum((n/200)*math.log2(n/200) for n in identity_counts.values() if n)
        report.append({"gene":gene,"complete_P2_ledgers":3,"state_rows":24,"delay_checks":200,
                       "fresh_fold_measurements":len(frames),"Delay_identity_outcome_Shannon_bits":entropy,
                       "joint_state_and_partner_maps_verified":True,"source_reconciliation":comparison})
    source_records = json.loads((root/"source_inspection/original_sources.json").read_text())
    original_paths_checked = 0
    for path_record in source_records:
        # Packaged source bytes are always checked. The original workspace is
        # additionally checked when available; unpacking does not require it.
        source_copy = root/"original_sources"/path_record["name"]
        assert hashlib.sha256(source_copy.read_bytes()).hexdigest() == path_record["sha256"]
        original_path = Path(path_record["source_path"])
        if original_path.is_file():
            assert hashlib.sha256(original_path.read_bytes()).hexdigest() == path_record["sha256"]
            original_paths_checked += 1
    summary_rows=list(csv.DictReader((root/"outputs/Coupled_Reversion_Summary.csv").open()))
    assert len(summary_rows)==8 and {x["gene"] for x in summary_rows}=={x["gene"] for x in inputs}
    for x in summary_rows:
        result=json.loads((root/"outputs"/f"{x['gene']}_37C.json").read_text())
        assert float(x["return_delta_mfe_kcal_mol"]) == result["returned_measurement"]["delta_mfe_kcal_mol"]
        assert int(x["return_base_pair_distance"]) == result["returned_measurement"]["base_pair_distance"]
        assert int(x["return_sequence_hamming"]) == result["returned_measurement"]["sequence_hamming_full_transcript"]
    result={"complete":True,"lanes":report,"total_complete_P2_ledgers":24,"total_state_rows":192,
            "total_Delay_checks":1600,"total_fresh_full_transcript_folds":40,
            "original_research_files_unchanged":True if original_paths_checked == len(source_records) else None,
            "original_workspace_paths_checked":original_paths_checked,
            "packaged_original_source_files_unchanged":True,
            "verification":"Independent event reconstruction, stack-based partner parsing, pair-set distances, raw-frame energy reconciliation, all complete histories and Delay records; no new RNA folds performed by this verifier"}
    (root/"outputs/Independent_Verification.json").write_text(json.dumps(result,indent=2)+"\n")
    with (root/"outputs/Source_Reconciliation.csv").open("w",newline="") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(reconciliations[0]));writer.writeheader();writer.writerows(reconciliations)
    print(json.dumps({k:v for k,v in result.items() if k!="lanes"},indent=2))
    return result


if __name__=="__main__": main()
