# QTET mRNA coupled intervention-reversion rerun

Author and rights holder: Destiny Machwaya. The governing law is supplied and unchanged.

Eight original full-transcript RNA lanes at 37 °C were completed with ViennaRNA 2.7.2: TP53, HBB, LMNA, MECP2, GBA1, TTR, PAH, and HFE. All recorded exact computational sequence, selected-fold, and MFE return through complete coupled P2/P3 histories and Delay(200). The package contains 24 complete P2 histories, 192 component state rows, 1,600 live Delay checks, and 40 fresh whole-transcript fold measurements.

Start with QTET_mRNA_Coupled_Reversion_Results_20261008.md. Open QTET_mRNA_Coupled_Reversion_Rerun_20261008.html for the saved measured tables and figures, or the matching .ipynb for the executed cells. METHOD_CORRECTION.md explains the execution correction.

Original source notebooks and the complete prior intervention-reversion ZIP are preserved byte-identically in original_sources/. Frozen originally specified transcript versions, coordinates, and input hashes are in frozen_inputs/. All raw measurements and complete histories are in outputs/. No original research file was overwritten.

Install requirements.txt in a Python environment. From this folder, run `python verify_coupled_rerun.py` for independent verification without new RNA folds. `python coupled_rna_runner.py --workers 3` recovers matching complete outputs; source or observer mismatches are rejected. For a deliberately fresh repeat, make a separate copy with a new empty outputs/ folder.

The saved notebook was executed top to bottom through in-process IPython with captured native rich outputs because this runtime does not permit Jupyter kernel sockets. Counts 1–10, the full measured tables, and three native scientific figures are retained. The notebook resumes and checks the already completed RNA measurements.

MECP2 resumed from its saved native fold frames after an execution-session interruption. No completed fold was repeated on resumption; all five MECP2 frames and its complete Delay history are included. The original attempt, resumption, notebook execution, and independent checks are recorded in the logs and source_inspection/.

The completed rerun covers the original 37 °C molecular RNA panel. The previously prepared temperature arms and other tissue/cell/organoid continuations retain their source scope. Delay checks retain molecular state and frame provenance; no physical time units are added. SHA256SUMS.txt records every packaged file.
