"""Render RNA measurements from verified complete molecular-state records."""
from pathlib import Path
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import numpy as np

from verify_coupled_rerun import pairs, sha

LABELS=["3,3","0,0\nfirst","0,1","1,2","2,1","1,0","0,0\nfinal","Delay\n(200)"]
GOLD="#b68a13"
CHARCOAL="#30343b"


def traces(root):
    root=Path(root)
    panel=json.loads((root/"frozen_inputs/panel.json").read_text())
    rows=[]
    for row in panel:
        result=json.loads((root/"outputs"/f"{row['gene']}_37C.json").read_text())
        origin="".join(x for x in (root/"frozen_inputs"/f"{row['accession']}.reference.fasta").read_text().splitlines() if not x.startswith(">")).replace("U","T")
        current=origin
        frames={f["frame_id"]:f for f in result["fold_measurements"]}
        reference=frames[result["state_records"][1]["fold_frame_id"]]
        ref_pairs,_=pairs(reference["structure"])
        sequence,energy,topology=[],[],[]
        for event,state in zip(result["events"],result["state_records"]):
            if "coordinate" in event:
                i=event["coordinate"]-1
                assert current[i]==event["before"]
                current=current[:i]+event["after"]+current[i+1:]
            assert sha(current.replace("T","U"))==state["sequence_rna_sha256"]
            frame=frames[state["fold_frame_id"]]
            assert frame["sequence_rna_sha256"]==state["sequence_rna_sha256"]
            frame_pairs,_=pairs(frame["structure"])
            sequence.append(sum(a!=b for a,b in zip(current,origin)))
            energy.append(frame["mfe_kcal_mol"]-reference["mfe_kcal_mol"])
            topology.append(len(frame_pairs.symmetric_difference(ref_pairs)))
        rows.append({"gene":row["gene"],"length":row["length_nt"],"sequence":sequence,"energy":energy,"topology":topology})
    return rows


def styling():
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.labelcolor":CHARCOAL,
                         "text.color":CHARCOAL,"axes.edgecolor":"#989ca3","axes.spines.top":False,
                         "axes.spines.right":False,"figure.facecolor":"white","axes.facecolor":"white"})


def save(fig,root,name):
    path=Path(root)/"outputs/figures";path.mkdir(exist_ok=True)
    fig.text(.975,.972,"✿",ha="right",va="top",color=GOLD,fontsize=17)
    fig.savefig(path/name,dpi=150,bbox_inches="tight",facecolor="white")
    return fig


def sequence_history_figure(root):
    styling();data=traces(root)
    values=np.array([r["sequence"] for r in data])
    fig,ax=plt.subplots(figsize=(11,5.9))
    ax.imshow(values,cmap=ListedColormap(["#fffaf0",GOLD]),vmin=0,vmax=1,aspect="auto")
    for row in range(8):
        for col in range(8):ax.text(col,row,str(values[row,col]),ha="center",va="center",color="white" if values[row,col] else CHARCOAL)
    ax.set_xticks(range(8),LABELS);ax.set_yticks(range(8),[r["gene"] for r in data])
    ax.set_xlabel("Complete P2 traversal shared by all three P3 components",labelpad=13)
    ax.set_title("Full-transcript sequence differences from the shared reference",loc="left",pad=30,fontweight="bold")
    fig.text(.125,.90,"37 °C · eight original RNA lanes · values count differing nucleotides",fontsize=10,color="#666a72")
    ax.set_xticks(np.arange(-.5,8,1),minor=True);ax.set_yticks(np.arange(-.5,8,1),minor=True)
    ax.grid(which="minor",color="white",linewidth=2);ax.tick_params(which="minor",bottom=False,left=False)
    fig.tight_layout(rect=(0,.02,1,.89))
    return save(fig,root,"Full_RNA_Sequence_State_History.png")


def energy_reversion_figure(root):
    styling();data=traces(root)
    disease=np.array([r["energy"][3] for r in data]);returned=np.array([r["energy"][-1] for r in data])
    positions=np.arange(8)
    fig,ax=plt.subplots(figsize=(11,6.2))
    ax.hlines(positions,returned,disease,color="#c5c8cd",linewidth=1.7,zorder=1)
    ax.scatter(disease,positions,color=GOLD,s=65,label="1,2 disease-state readout",zorder=3)
    ax.scatter(returned,positions,facecolors="white",edgecolors=CHARCOAL,marker="D",s=48,label="Post-return Delay readout",zorder=4)
    ax.axvline(0,color="#7c818a",linewidth=1,zorder=0)
    for i,value in enumerate(disease):
        ax.annotate(f"{value:+.6f}",(value,i),xytext=(8,8),textcoords="offset points",fontsize=9)
    ax.set_yticks(positions,[r["gene"] for r in data]);ax.invert_yaxis()
    ax.set_xlabel("Measured Δ MFE from the matched reference (kcal/mol)")
    ax.set_xlim(min(disease.min(),returned.min())-.6,max(disease.max(),returned.max())+1.0)
    ax.set_ylim(7.7,-.8);ax.grid(axis="x",color="#e7e8eb",linewidth=.7)
    ax.set_title("Whole-transcript energy before inversion and after return",loc="left",pad=35,fontweight="bold")
    ax.legend(loc="upper center",bbox_to_anchor=(.51,1.08),ncol=2,frameon=False,fontsize=10)
    fig.text(.125,.035,"Return differences are calculated from fresh measured fold frames; none is preset to zero.",fontsize=10,color="#666a72")
    fig.tight_layout(rect=(0,.07,1,.97))
    return save(fig,root,"Full_RNA_Measured_Energy_Return.png")


def topology_history_figure(root):
    styling();data=traces(root)
    fig,axes=plt.subplots(4,2,figsize=(12.5,11),sharey=True)
    ymax=max(max(r["topology"]) for r in data)
    for ax,r in zip(axes.flat,data):
        y=r["topology"]
        ax.plot(range(8),y,color=GOLD,marker="o",markersize=4,linewidth=1.7)
        ax.set_xticks(range(8),LABELS,fontsize=9)
        ax.set_ylim(-2,ymax+9);ax.set_xlim(-.3,7.3)
        ax.set_title(f"{r['gene']} · {r['length']:,} nt",loc="left",fontsize=12,fontweight="bold")
        ax.grid(axis="y",color="#e7e8eb",linewidth=.7)
        ax.annotate(str(y[3]),(3,y[3]),xytext=(0,7),textcoords="offset points",ha="center",fontsize=10)
    for ax in axes[:,0]:ax.set_ylabel("Differing base pairs")
    fig.suptitle("Whole-transcript pairing through complete P2/P3 return",x=.06,ha="left",fontsize=16,fontweight="bold",y=.985)
    fig.text(.06,.956,"37 °C · one shared vertical scale · ordered states are not a physical time axis",fontsize=10,color="#666a72")
    fig.tight_layout(rect=(0,.02,1,.945),h_pad=2.2,w_pad=2)
    return save(fig,root,"Full_RNA_Pairing_State_History.png")


if __name__=="__main__":
    root=Path(__file__).resolve().parent
    for function in [sequence_history_figure,energy_reversion_figure,topology_history_figure]:plt.close(function(root))
