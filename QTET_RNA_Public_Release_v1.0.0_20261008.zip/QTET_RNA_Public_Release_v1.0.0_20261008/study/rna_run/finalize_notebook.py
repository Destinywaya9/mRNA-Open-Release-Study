"""Execute and export the notebook after all corrected RNA lanes are complete."""
from pathlib import Path
import json
import base64
import re
import time
import traceback

import nbformat
from nbconvert import HTMLExporter
from IPython.core.interactiveshell import InteractiveShell
from IPython.core.pylabtools import print_figure
from IPython.utils.capture import capture_output
from matplotlib.figure import Figure

from verify_coupled_rerun import main as verify
from build_rerun_notebook import build


def execute_cells(notebook):
    # This runtime does not permit TCP or IPC kernel sockets. Execute real
    # notebook cells through an in-process IPython shell and capture its
    # native rich display outputs; do not manufacture execution records.
    shell = InteractiveShell.instance()
    shell.display_formatter.formatters["image/png"].for_type(
        Figure, lambda figure: print_figure(figure, fmt="png", bbox_inches="tight")
    )
    for cell in notebook.cells:
        if cell.cell_type != "code":
            continue
        with capture_output(stdout=True, stderr=True, display=True) as captured:
            result = shell.run_cell(cell.source, store_history=True)
        cell.execution_count = result.execution_count
        outputs = []
        if captured.stdout:
            outputs.append(nbformat.v4.new_output("stream", name="stdout", text=captured.stdout))
        if captured.stderr:
            outputs.append(nbformat.v4.new_output("stream", name="stderr", text=captured.stderr))
        for rich in captured.outputs:
            data = {key: base64.b64encode(value).decode() if isinstance(value, bytes) else value
                    for key, value in rich.data.items()}
            outputs.append(nbformat.v4.new_output("display_data", data=data, metadata=rich.metadata))
        error = result.error_before_exec or result.error_in_exec
        if error:
            outputs.append(nbformat.v4.new_output("error", ename=type(error).__name__,
                                                 evalue=str(error), traceback=traceback.format_exception(error)))
        cell.outputs = outputs
        if error:
            raise RuntimeError(f"Notebook cell {cell.execution_count} failed") from error
    notebook.metadata["execution"] = {
        "mode": "top-to-bottom in-process IPython execution with captured native rich outputs",
        "runtime_reason": "socket-based Jupyter kernel startup is unavailable in this execution environment",
        "RNA_runs": "completed native full-transcript measurements, recovered and independently verified in the cells",
    }


def export_preview(notebook, root):
    # --target installations keep Jupyter's data files beside the packages.
    template_root = root / "dependencies/share/jupyter/nbconvert/templates"
    options = {"extra_template_basedirs": [str(template_root)],
               "extra_template_paths": [str(template_root)]} if template_root.is_dir() else {}
    html, _ = HTMLExporter(template_name="lab", **options).from_notebook_node(notebook)
    html = re.sub(r'<script\b[^>]*\bsrc=["\']https?://[^"\']+["\'][^>]*>.*?</script>',
                  "", html, flags=re.S | re.I)
    preview = root / "QTET_mRNA_Coupled_Reversion_Rerun_20261008.html"
    preview.write_text(html)
    return preview


def main(root=None):
    root=Path(root or Path(__file__).resolve().parent)
    started=time.monotonic()
    while not (root/"outputs/MECP2_37C.json").exists():
        if time.monotonic()-started>600:
            raise TimeoutError("Final RNA lane still incomplete; retain the existing checkpoints")
        time.sleep(5)
    status=json.loads((root/"outputs/run_status.json").read_text())
    while not status["complete"]:
        if time.monotonic()-started>600: raise TimeoutError("Rerun status has not completed")
        time.sleep(2)
        status=json.loads((root/"outputs/run_status.json").read_text())
    print("INDEPENDENT_VERIFICATION_START",flush=True)
    verify(root)
    notebook_path=build(root)
    notebook=nbformat.read(notebook_path,as_version=4)
    print("NOTEBOOK_EXECUTION_START",flush=True)
    execute_cells(notebook)
    nbformat.validate(notebook)
    nbformat.write(notebook,notebook_path)
    # Native figure/table outputs remain embedded; the preview needs no remote
    # rendering scripts to display the measured results.
    preview = export_preview(notebook, root)
    print("NOTEBOOK_COMPLETE",notebook_path,flush=True)
    print("HTML_PREVIEW_COMPLETE",preview,flush=True)


if __name__=="__main__":main()
