"""Validate the saved presentation and package the complete measured rerun."""
from pathlib import Path
from html.parser import HTMLParser
import ast
import base64
import hashlib
import json
import re
import zipfile

import nbformat


class ImageSources(HTMLParser):
    def __init__(self):
        super().__init__()
        self.sources = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            self.sources.append(dict(attrs).get("src", ""))


def main(root=None):
    root = Path(root or Path(__file__).resolve().parent)
    stem = "QTET_mRNA_Coupled_Reversion_Rerun_20261008"
    nbpath = root / (stem + ".ipynb")
    notebook = nbformat.read(nbpath, as_version=4)
    nbformat.validate(notebook)
    code = [c for c in notebook.cells if c.cell_type == "code"]
    errors = [o for c in code for o in c.outputs if o.output_type == "error"]
    counts = [c.execution_count for c in code]
    assert counts == list(range(1, 11)) and not errors
    pngs = [o.data["image/png"] for c in code for o in c.outputs
            if "image/png" in o.get("data", {})]
    assert len(pngs) == 3
    for png in pngs:
        assert base64.b64decode(png).startswith(b"\x89PNG\r\n\x1a\n")
    htmlpath = root / (stem + ".html")
    html = htmlpath.read_text()
    parser = ImageSources()
    parser.feed(html)
    assert len(parser.sources) == 3
    for src in parser.sources:
        assert src.startswith("data:image/png;base64,")
        assert base64.b64decode(src.split(",", 1)[1]).startswith(b"\x89PNG\r\n\x1a\n")
    assert not re.search(r'<script\b[^>]*\bsrc=["\']https?://', html, re.I)
    streams = "".join(o.get("text", "") for c in code for o in c.outputs
                      if o.output_type == "stream")
    assert streams.count("INHERIT_COMPLETED") == 8
    scripts = ["coupled_rna_runner.py", "verify_coupled_rerun.py",
               "check_execution_binding.py", "plot_rerun.py",
               "build_rerun_notebook.py", "finalize_notebook.py", "package_rerun.py"]
    for script in scripts:
        ast.parse((root / script).read_text(), filename=script)
    checks = json.loads((root / "outputs/Independent_Verification.json").read_text())
    assert checks["complete"] and checks["original_research_files_unchanged"]
    assert len(list((root / "outputs/fold_frames").glob("*.json"))) == 40
    assert hashlib.sha256((root / "coupled_rna_runner.py").read_bytes()).hexdigest() == (
        "7454028a0467e0aef3ddab0fcbca9bb5e376069e0e75f1c1ccf52c07421dc27d")
    qa = {
        "notebook_code_cells": len(code), "execution_counts": counts,
        "saved_errors": len(errors), "native_inline_figures": len(pngs),
        "embedded_HTML_figures": len(parser.sources),
        "notebook_recovered_completed_RNA_lanes": 8,
        "RNA_fold_measurements_repeated_for_presentation": False,
        "native_figure_visual_review": "All three inspected; labels and complete eight-lane data readable",
        "whole_HTML_browser_render": "Unavailable: no Chromium executable in the runtime; inline image data and HTML content validated",
        "runnable_scripts_parse": scripts, "complete_primary_native_fold_frames": 40,
        "independent_verification_complete": True, "original_research_files_unchanged": True,
    }
    (root / "source_inspection/Package_QA.json").write_text(json.dumps(qa, indent=2) + "\n")
    (root / "source_inspection/Notebook_HTML_Export.json").write_text(json.dumps({
        "export": "Completed from the executed notebook", "RNA_measurements_repeated": False,
        "path": htmlpath.name, "bytes": htmlpath.stat().st_size,
    }, indent=2) + "\n")
    (root / "README.md").write_text("""# QTET mRNA coupled intervention-reversion rerun

Author and rights holder: Destiny Machwaya. The governing law is supplied and unchanged.

Eight original full-transcript RNA lanes at 37 °C were completed with ViennaRNA 2.7.2: TP53, HBB, LMNA, MECP2, GBA1, TTR, PAH, and HFE. All recorded exact computational sequence, selected-fold, and MFE return through complete coupled P2/P3 histories and Delay(200). The package contains 24 complete P2 histories, 192 component state rows, 1,600 live Delay checks, and 40 fresh whole-transcript fold measurements.

Start with QTET_mRNA_Coupled_Reversion_Results_20261008.md. Open QTET_mRNA_Coupled_Reversion_Rerun_20261008.html for the saved measured tables and figures, or the matching .ipynb for the executed cells. METHOD_CORRECTION.md explains the execution correction.

Original source notebooks and the complete prior intervention-reversion ZIP are preserved byte-identically in original_sources/. Frozen originally specified transcript versions, coordinates, and input hashes are in frozen_inputs/. All raw measurements and complete histories are in outputs/. No original research file was overwritten.

Install requirements.txt in a Python environment. From this folder, run `python verify_coupled_rerun.py` for independent verification without new RNA folds. `python coupled_rna_runner.py --workers 3` recovers matching complete outputs; source or observer mismatches are rejected. For a deliberately fresh repeat, make a separate copy with a new empty outputs/ folder.

The saved notebook was executed top to bottom through in-process IPython with captured native rich outputs because this runtime does not permit Jupyter kernel sockets. Counts 1–10, the full measured tables, and three native scientific figures are retained. The notebook resumes and checks the already completed RNA measurements.

MECP2 resumed from its saved native fold frames after an execution-session interruption. No completed fold was repeated on resumption; all five MECP2 frames and its complete Delay history are included. The original attempt, resumption, notebook execution, and independent checks are recorded in the logs and source_inspection/.

The completed rerun covers the original 37 °C molecular RNA panel. The previously prepared temperature arms and other tissue/cell/organoid continuations retain their source scope. Delay checks retain molecular state and frame provenance; no physical time units are added. SHA256SUMS.txt records every packaged file.
""")
    files = []
    for filename in scripts + ["requirements.txt", "environment.json", "run_request.json",
                              "METHOD_CORRECTION.md", "README.md",
                              "QTET_mRNA_Coupled_Reversion_Results_20261008.md",
                              nbpath.name, htmlpath.name, "run.log", "resume.log",
                              "notebook_execution.log", "notebook_execution_completed.log"]:
        path = root / filename
        assert path.is_file()
        files.append(path)
    extracted_inspection_code = {"QTET_mRNA_Cross_Pathology_Panel_v1.py",
                                 "QTET_mRNA_Full_P2P3_Intervention_Colab_v3.py"}
    for dirname in ["original_sources", "frozen_inputs", "outputs", "source_inspection"]:
        for path in sorted((root / dirname).rglob("*")):
            if (path.is_file() and "__pycache__" not in path.parts
                    and path.name not in extracted_inspection_code):
                files.append(path)
    files = sorted(set(files), key=lambda p: p.relative_to(root).as_posix())
    manifest = root / "SHA256SUMS.txt"
    manifest.write_text("".join(hashlib.sha256(p.read_bytes()).hexdigest() + "  "
                                + p.relative_to(root).as_posix() + "\n" for p in files))
    archive = root / (stem + ".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as bundle:
        for path in files + [manifest]:
            bundle.write(path, path.relative_to(root).as_posix())
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        for path in files:
            assert hashlib.sha256(bundle.read(path.relative_to(root).as_posix())).hexdigest() == (
                hashlib.sha256(path.read_bytes()).hexdigest())
    print(json.dumps({"complete": True, "file_count": len(files) + 1,
                      "zip_bytes": archive.stat().st_size, "QA": qa}, indent=2))


if __name__ == "__main__":
    main()
