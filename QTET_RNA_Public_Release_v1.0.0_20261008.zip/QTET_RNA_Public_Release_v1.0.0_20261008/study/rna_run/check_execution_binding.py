"""Reject concrete ways of detaching the RNA readout from full molecular P3."""
from pathlib import Path
import copy
import json

from coupled_rna_runner import MolecularP3, P2Carrier, validate_record


def main(root=None):
    root=Path(root or Path(__file__).resolve().parent)
    record=json.loads((root/"outputs/TTR_37C.json").read_text())
    assert validate_record(record) and all(record["validation"].values())
    checks=[]
    def reject(name,mutation):
        modified=copy.deepcopy(record);mutation(modified)
        try: validate_record(modified)
        except ValueError as exc: checks.append({"case":name,"result":"rejected","reason":str(exc)})
        else: raise AssertionError(name+" was accepted")
    reject("missing_flanking_component",lambda r:r["P3_component_ledger"].pop(0))
    reject("out_of_order_state",lambda r:r["state_records"].__setitem__(4,r["state_records"][3]))
    reject("observer_input_detached",lambda r:r["P3_component_ledger"][7].__setitem__("shared_molecule_sequence_rna_sha256","different input"))
    reject("component_prefix_incomplete",lambda r:r["P3_component_ledger"][13].__setitem__("complete_P2_prefix_length",2))
    reject("Delay_iteration_removed",lambda r:r["delay_records"].pop(50))
    row=record["input"]
    origin="".join(x for x in (root/"frozen_inputs"/f"{row['accession']}.reference.fasta").read_text().splitlines() if not x.startswith(">")).replace("U","T")
    try: MolecularP3(row,origin,[P2Carrier(2,row["mrna_positions"][1],"D_2")])
    except ValueError: checks.append({"case":"center_only_P3","result":"rejected"})
    else: raise AssertionError("Center-only P3 accepted")
    mol=MolecularP3(row,origin,[P2Carrier(i+1,p,f"D_{i+1}") for i,p in enumerate(row["mrna_positions"])])
    try: mol.transition(4)
    except ValueError: checks.append({"case":"inversion_without_differentiation_history","result":"rejected"})
    else: raise AssertionError("Inversion without history accepted")
    result={"valid_actual_TTR_run":"passed","negative_implementation_checks":checks,
            "scope":"Execution binding checks on copied records; original data and supplied law are unchanged"}
    (root/"source_inspection/Coupling_Implementation_Checks.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result,indent=2))
    return result


if __name__=="__main__":main()
