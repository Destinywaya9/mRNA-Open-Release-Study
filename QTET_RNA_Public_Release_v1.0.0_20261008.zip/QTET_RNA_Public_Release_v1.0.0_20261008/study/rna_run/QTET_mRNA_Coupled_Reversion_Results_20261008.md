# QTET molecular RNA reversion — corrected coupled execution

**Author and rights holder: Destiny Machwaya.** The governing law is supplied and unchanged.

The eight original full-transcript RNA lanes were rerun at **37 °C** with the source-pinned **ViennaRNA 2.7.2** observer. All eight recorded exact sequence, selected-fold, and MFE return through complete molecular P2/P3 histories and Delay(200).

The completed data contain **24 complete P2 ledgers, 192 state rows, 1,600 coupled Delay checks, and 40 fresh full-transcript fold measurements**. Every state carries all three P2 components, including both unchanged flanks. Whole-transcript energy is retained as one molecular readout.

Tensor P2 remains `3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`.

Tensor P3 remains `P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]`.

## Fresh measured outcomes

Displayed energy differences are rounded to six decimals. Raw JSON/CSV retains full precision. Pair distances count differing base pairs in the selected whole-transcript folds.

| Gene | mRNA center | Reference → differentiated → returned | Disease Δ MFE (kcal/mol) | Disease pair distance | Return Δ MFE | Return pair distance | Return sequence differences |
| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |
| TP53 | 666 | CGC → CAC → CGC | -0.399963 | 0 | 0.000000 | 0 | 0 |
| HBB | 70 | GAG → GTG → GAG | 0.000000 | 0 | 0.000000 | 0 | 0 |
| LMNA | 2032 | GCG → GTG → GCG | 0.000000 | 0 | 0.000000 | 0 | 0 |
| MECP2 | 699 | ACG → ATG → ACG | -1.100098 | 7 | 0.000000 | 0 | 0 |
| GBA1 | 1363 | AAC → AGC → AAC | -1.100037 | 27 | 0.000000 | 0 | 0 |
| TTR | 174 | CGT → CAT → CGT | -0.400009 | 0 | 0.000000 | 0 | 0 |
| PAH | 1336 | TCG → TTG → TCG | -0.100037 | 86 | 0.000000 | 0 | 0 |
| HFE | 857 | TGC → TAC → TGC | 5.599976 | 46 | 0.000000 | 0 | 0 |

HBB and LMNA retain their authentic sequence differentiation and reversion despite zero selected MFE/topology displacement. No fold deviation is invented for those lanes.

## Execution correction

The original implementation computed molecular changes and folds separately, then assembled histories; the prepared v3 summary also preset some return metrics to zero. The corrected implementation executes the supplied differentiation at `0,1` and its captured inversion pair at `2,1` within one synchronized, complete P3 traversal. The observer receives the current full RNA state. Every component's bases and pairing partners are projected from that same measured whole-transcript fold.

Return metrics are calculated from fresh measured frames. Missing components, wrong state order, incomplete component histories, detached observer inputs, and incomplete Delay records are rejected. Independent verification reconstructs the events, parses all pairing partners, checks pair-set distances and measured energy differences, and reconciles the source results.

## Delay(200)

All 200 live shared-state checks are retained for each lane. Checks 1 and 200 independently refold the returned full transcript; intervening checks identify the retained fold measurement and verify current molecular identity and complete P3. No unprovided physical time units or independently evolved trajectories are added.

## Source and scope

The RNA measurements reproduce the prior eight-lane disease-state energies at their recorded precision and the prior pair/changed-position distances. Exact original source artifacts and earlier complete results are retained byte-identically. The author's explicit rerun instruction authorizes this affected baseline repeat; unrelated completed atlases and the transcript-wide coordinate field remain inherited.

This completed package is the molecular mRNA intervention-reversion embodiment. The original v3 30/33/40/42 °C extensions remain prepared source, and cell/tissue-fold/organoid continuation retains its own source and evidence requirements.

## Files

- `QTET_mRNA_Coupled_Reversion_Rerun_20261008.ipynb`: executed notebook with measured tables and figures.
- `coupled_rna_runner.py`: corrected state-coupled execution with frozen-input checkpoints.
- `verify_coupled_rerun.py`: independent complete data reconciliation.
- `check_execution_binding.py`: explicit decoupling fault checks.
- `outputs/`: complete raw frames, coupled state/Delay records, partner maps, source reconciliation, and summaries.
- `frozen_inputs/`: exact originally specified transcript versions, coordinates, and hashed source inputs.
- `original_sources/`: byte-identical prior source notebooks and complete intervention-reversion archive.
- `METHOD_CORRECTION.md`, `environment.json`, and `requirements.txt`: operation, observer settings, and reproduction context.

Open the notebook from the unpacked package. Its execution cell resumes/reconciles matching completed results; it does not silently repeat fresh RNA folds. Use a separate copy with an empty outputs folder for an intentionally new repeat.
