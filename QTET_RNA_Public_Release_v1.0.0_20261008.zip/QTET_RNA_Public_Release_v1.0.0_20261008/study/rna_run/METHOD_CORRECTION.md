# Coupled molecular mRNA intervention-reversion execution

Author and rights holder: Destiny Machwaya. The governing law is supplied. Original mathematics, definitions, research artifacts, and prior results are retained unchanged.

This rerun follows the author's 8 October 2026 instruction to redo the RNA reversion study and correct the execution decoupling. It executes the eight original full-transcript, authentic-variant lanes at the original 37 °C condition with ViennaRNA 2.7.2. The previously prepared 30/33/40/42 °C extensions remain separately identified in the original v3 source.

## Invariant architecture

`3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`

`P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]`

Every assigned coordinate retains its complete P2. The three instances share one molecular RNA state and advance through the same complete traversal. Both unchanged flanks remain present. No P2 state is distributed among bases, and no P2 weighting or adaptive rule is introduced.

The reference identifier in the execution records is a provenance label for the shared source reference. It does not redefine `M_E ≡ 0_Q`, add a coordinate, or replace the supplied folded total-state law.

## Implementation correction

The original panel cell 10 and v3 cell 5 compute reference/differentiated folds separately, perform an inverse nucleotide assignment, and then assemble state dictionaries. V3 cells 7 and 9 construct component histories afterward and preset several post-intervention metrics to zero. The thermal block does not emit full per-temperature component histories.

The corrected runner binds the same disclosed differentiation/inversion operation to the live full P2/P3 execution:

1. Require all three exact coordinate-local embeddings and complete synchronized prefixes before each transition.
2. Execute the authentic differentiation within `0,1`; capture its exact before/after pair from the live molecular state.
3. Retain that same molecule at the `1,2` readout.
4. Execute the captured inversion pair within `2,1`, through the complete shared P3 history.
5. Read the current whole transcript after each event. Observe all three carrier bases and partners from the same full-transcript fold; do not add independent carrier energies or replace the molecular context with a three-base fold.
6. Verify return at `1,0`, retain final `0,0` closure, and complete post-return Delay(200).

The new data report actual RNA measurements and their input hashes. Energy differences, pair distances, sequence differences, and return outcomes are calculated from measured frames; no return value is preset to zero. Reads of unchanged state explicitly identify the retained measurement and verify its live input hash.

## Delay and measurements

Each lane performs five fresh full-transcript folds: entry/reference, authentic differentiation, inversion-paired return, and Delay checks 1 and 200. The other Delay iterations inspect the live shared molecular state and retain the identified unchanged fold measurement. Every iteration records all three complete P2 histories, carrier bases/partners, source-reference identity, and measured-frame provenance.

Delay(200) remains post-return spacing/check logic in this computational embodiment. The record does not assign unprovided physical time units or count unchanged-state checks as independently evolved trajectories.

## Evidence retained

The entire previous intervention-reversion source package and notebooks are copied byte-identically into `original_sources/`. Earlier observed outcomes remain recoverable, and the corrected rerun reconciles its fresh disease-state measurements with those records. The archived architecture/order/removal atlases are retained rather than gratuitously repeated.

`frozen_inputs/` contains the exact originally specified accession versions, normalized full-transcript RNA, coordinate maps, source bytes, and hashes. Only the original source's T→U folding normalization is used.

`outputs/` contains raw fresh fold frames, all coupled state records, three complete P2 ledgers per lane, every Delay check, actual return metrics, paired no-intervention readouts, and independent reconciliation. These are computational molecular P2/P3 measurements; no cell/tissue-fold/organoid arms are substituted for them.

## Reproduction

Install `requirements.txt`, then run `python coupled_rna_runner.py --workers 3` from this package. The runner inherits matching completed checkpoints; it refuses input/environment/source mismatches. Preserve existing outputs when reviewing this execution. For an intentionally fresh repeat, use a separate copy of this package with a new empty `outputs/` folder.

Run `python verify_coupled_rerun.py` to independently reconstruct events and validate raw frames, all partner maps, complete histories, reported differences, and source preservation without repeating RNA folds.
