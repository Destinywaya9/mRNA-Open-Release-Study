"""Build the reviewable notebook and report from completed, verified RNA runs."""
from pathlib import Path
import csv
import json

import nbformat


def make_report(root):
    rows=list(csv.DictReader((root/"outputs/Coupled_Reversion_Summary.csv").open()))
    checks=json.loads((root/"outputs/Independent_Verification.json").read_text())
    assert len(rows)==8 and checks["complete"]
    lines=[
        "# QTET molecular RNA reversion — corrected coupled execution",
        "",
        "**Author and rights holder: Destiny Machwaya.** The governing law is supplied and unchanged.",
        "",
        "The eight original full-transcript RNA lanes were rerun at **37 °C** with the source-pinned **ViennaRNA 2.7.2** observer. All eight recorded exact sequence, selected-fold, and MFE return through complete molecular P2/P3 histories and Delay(200).",
        "",
        "The completed data contain **24 complete P2 ledgers, 192 state rows, 1,600 coupled Delay checks, and 40 fresh full-transcript fold measurements**. Every state carries all three P2 components, including both unchanged flanks. Whole-transcript energy is retained as one molecular readout.",
        "",
        "Tensor P2 remains `3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`.",
        "",
        "Tensor P3 remains `P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]`.",
        "",
        "## Fresh measured outcomes",
        "",
        "Displayed energy differences are rounded to six decimals. Raw JSON/CSV retains full precision. Pair distances count differing base pairs in the selected whole-transcript folds.",
        "",
        "| Gene | mRNA center | Reference → differentiated → returned | Disease Δ MFE (kcal/mol) | Disease pair distance | Return Δ MFE | Return pair distance | Return sequence differences |",
        "| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in rows:
        run=json.loads((root/"outputs"/f"{row['gene']}_37C.json").read_text())
        states=run["state_records"]
        triplets=f"{states[1]['triplet']} → {states[2]['triplet']} → {states[-1]['triplet']}"
        lines.append(f"| {row['gene']} | {row['mrna_center']} | {triplets} | {float(row['disease_delta_mfe_kcal_mol']):.6f} | {row['disease_base_pair_distance']} | {float(row['return_delta_mfe_kcal_mol']):.6f} | {row['return_base_pair_distance']} | {row['return_sequence_hamming']} |")
    lines += [
        "",
        "HBB and LMNA retain their authentic sequence differentiation and reversion despite zero selected MFE/topology displacement. No fold deviation is invented for those lanes.",
        "",
        "## Execution correction",
        "",
        "The original implementation computed molecular changes and folds separately, then assembled histories; the prepared v3 summary also preset some return metrics to zero. The corrected implementation executes the supplied differentiation at `0,1` and its captured inversion pair at `2,1` within one synchronized, complete P3 traversal. The observer receives the current full RNA state. Every component's bases and pairing partners are projected from that same measured whole-transcript fold.",
        "",
        "Return metrics are calculated from fresh measured frames. Missing components, wrong state order, incomplete component histories, detached observer inputs, and incomplete Delay records are rejected. Independent verification reconstructs the events, parses all pairing partners, checks pair-set distances and measured energy differences, and reconciles the source results.",
        "",
        "## Delay(200)",
        "",
        "All 200 live shared-state checks are retained for each lane. Checks 1 and 200 independently refold the returned full transcript; intervening checks identify the retained fold measurement and verify current molecular identity and complete P3. No unprovided physical time units or independently evolved trajectories are added.",
        "",
        "## Source and scope",
        "",
        "The RNA measurements reproduce the prior eight-lane disease-state energies at their recorded precision and the prior pair/changed-position distances. Exact original source artifacts and earlier complete results are retained byte-identically. The author's explicit rerun instruction authorizes this affected baseline repeat; unrelated completed atlases and the transcript-wide coordinate field remain inherited.",
        "",
        "This completed package is the molecular mRNA intervention-reversion embodiment. The original v3 30/33/40/42 °C extensions remain prepared source, and cell/tissue-fold/organoid continuation retains its own source and evidence requirements.",
        "",
        "## Files",
        "",
        "- `QTET_mRNA_Coupled_Reversion_Rerun_20261008.ipynb`: executed notebook with measured tables and figures.",
        "- `coupled_rna_runner.py`: corrected state-coupled execution with frozen-input checkpoints.",
        "- `verify_coupled_rerun.py`: independent complete data reconciliation.",
        "- `check_execution_binding.py`: explicit decoupling fault checks.",
        "- `outputs/`: complete raw frames, coupled state/Delay records, partner maps, source reconciliation, and summaries.",
        "- `frozen_inputs/`: exact originally specified transcript versions, coordinates, and hashed source inputs.",
        "- `original_sources/`: byte-identical prior source notebooks and complete intervention-reversion archive.",
        "- `METHOD_CORRECTION.md`, `environment.json`, and `requirements.txt`: operation, observer settings, and reproduction context.",
        "",
        "Open the notebook from the unpacked package. Its execution cell resumes/reconciles matching completed results; it does not silently repeat fresh RNA folds. Use a separate copy with an empty outputs folder for an intentionally new repeat.",
    ]
    report=root/"QTET_mRNA_Coupled_Reversion_Results_20261008.md"
    report.write_text("\n".join(lines)+"\n")
    return report


def build(root=None):
    root=Path(root or Path(__file__).resolve().parent)
    report=make_report(root)
    cells=[]
    def md(text): cells.append(nbformat.v4.new_markdown_cell(text))
    def code(text): cells.append(nbformat.v4.new_code_cell(text))
    md("# QTET molecular RNA reversion: corrected coupled execution\n\n**Author and rights holder: Destiny Machwaya**\n\nThe governing law is supplied. Tensor P2/P3, exact transcript versions, full molecular context, and prior research artifacts are preserved.")
    md("## Results at a glance\n\nEight original full-transcript lanes at **37 °C**, ViennaRNA **2.7.2**. Exact sequence/fold/MFE return: **8/8**. Complete P2 ledgers: **24**; state rows: **192**; live Delay checks: **1,600**; fresh whole-transcript fold measurements: **40**. Both unchanged flanks retain complete P2.\n\nReturn values are computed from measured frames. The notebook resumes the completed corrected rerun, independently reconciles it, and displays its full results.")
    md("## Source lock and method\n\n`3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`\n\n`P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]`\n\nEach molecular transition and structural readout shares the same live RNA state, reference identifier, coordinate map, and three complete P2 prefixes. The exact `0,1` differentiation pair is inverted within `2,1`. ViennaRNA measures the downstream full-transcript fold; its score does not select or change the invariant operator.\n\nThe logging reference identifier does not redefine `M_E ≡ 0_Q` or add a fifth coordinate. See `METHOD_CORRECTION.md` for the precise implementation correction.\n\nRun from the unpacked package. Install `requirements.txt` if needed; the notebook makes no transcript downloads.")
    code("from pathlib import Path\nimport json, subprocess, sys\nimport pandas as pd\nimport matplotlib.pyplot as plt\nfrom IPython.display import display\nROOT = Path.cwd()\nassert (ROOT / 'frozen_inputs/panel.json').is_file(), 'Open from the unpacked rerun package'\ninputs = json.loads((ROOT / 'frozen_inputs/panel.json').read_text())\nenvironment = json.loads((ROOT / 'environment.json').read_text())\nassert environment['packages']['ViennaRNA'] == '2.7.2'\ndisplay(pd.DataFrame(inputs)[['gene','accession','length_nt','mrna_positions','reference_triplet']])\nprint('P2/P3 unchanged; eight frozen full transcripts; observer temperature 37 °C.')")
    md("### Execute or resume the corrected molecular cycle\n\nThe runner recovers matching completed outputs and verifies their source binding. Without those outputs it performs the authorized RNA run and saves checkpoints. No original research file is overwritten.")
    code("execution = subprocess.run([sys.executable, str(ROOT/'coupled_rna_runner.py'), '--root', str(ROOT), '--workers', '3'], capture_output=True, text=True)\nprint(execution.stdout)\nif execution.returncode:\n    print(execution.stderr)\n    raise RuntimeError('RNA run incomplete; inspect retained logs/checkpoints')")
    md("### Independently verify complete data binding\n\nThis reconstructs live sequence events, independently parses all fold partners, reconciles measured energy/pair differences, and verifies all three histories and 200 Delay checks. The fault checks reject explicit ways of detaching the data from complete P3.")
    code("from verify_coupled_rerun import main as verify\nfrom check_execution_binding import main as binding_checks\nverification = verify(ROOT)\nfault_checks = binding_checks(ROOT)\nprint('All complete RNA histories and measured frames verified.')")
    md("## Fresh molecular measurements\n\nThe table preserves exact sequence return alongside independent energy and topology channels. CSV/JSON stores full floating-point precision; notebook display rounds to six decimals.")
    code("summary = pd.read_csv(ROOT/'outputs/Coupled_Reversion_Summary.csv')\npd.options.display.float_format = '{:.6f}'.format\ndisplay(summary[['gene','mrna_center','disease_delta_mfe_kcal_mol','return_delta_mfe_kcal_mol','disease_base_pair_distance','return_base_pair_distance','return_sequence_hamming','complete_P2P3','Delay200']])")
    md("### All three complete P2 components in one molecular P3\n\nEvery row below comes from the same full-transcript measurement for its lane/state. Both unchanged flanks retain complete histories. Pairing coordinates are structural observations; an unpaired carrier has partner 0.")
    code("ledger = pd.read_csv(ROOT/'outputs/Complete_P2P3_State_Ledgers.csv')\nreference_rows = ledger[ledger.state_index==1].set_index(['gene','component_index'])\ndisease_rows = ledger[ledger.state_index==3].set_index(['gene','component_index'])\nreturned_rows = ledger[ledger.state_index==6].set_index(['gene','component_index'])\ncomponents = reference_rows[['P3_component','mrna_coordinate','base','RNA_partner_coordinate']].rename(columns={'base':'reference_base','RNA_partner_coordinate':'reference_partner'})\ncomponents['disease_base'] = disease_rows['base']\ncomponents['disease_partner'] = disease_rows['RNA_partner_coordinate']\ncomponents['returned_base'] = returned_rows['base']\ncomponents['returned_partner'] = returned_rows['RNA_partner_coordinate']\ncomponents['complete_P2_states'] = ledger.groupby(['gene','component_index'])['state'].nunique()\ndisplay(components.reset_index())\nassert len(ledger)==192 and ledger.all_three_synchronized.all()\nprint('24 complete P2 ledgers; 192 state rows; shared input/fold/reference binding independently verified.')")
    md("### Complete sequence differentiation and return\n\nThe ordered axis is the supplied P2 traversal, not an invented physical time scale. Each lane retains the authentic nucleotide deviation at `0,1`/`1,2` and measured identity after inversion.")
    code("from plot_rerun import sequence_history_figure, energy_reversion_figure, topology_history_figure\nfigure = sequence_history_figure(ROOT)\ndisplay(figure)\nplt.close(figure)")
    md("### Whole-transcript energy readout\n\nAll plotted differences are calculated from raw measured fold frames. HBB and LMNA retain zero selected MFE change together with authentic sequence differentiation/reversion.")
    code("figure = energy_reversion_figure(ROOT)\ndisplay(figure)\nplt.close(figure)")
    md("### Whole-transcript pairing return through the complete traversal\n\nShared vertical scale shows the measured number of differing base pairs. Energy and topology are retained as separate channels.")
    code("figure = topology_history_figure(ROOT)\ndisplay(figure)\nplt.close(figure)")
    md("## Delay(200) and paired control readouts\n\nEvery lane retains 200 live shared-state checks. Checks 1 and 200 independently refold the returned full transcript. Intermediate checks identify the retained measured fold and verify the live molecule and complete P3. This does not assign unprovided physical duration or count unchanged-state checks as independently evolved trajectories.")
    code("delay = pd.read_csv(ROOT/'outputs/Coupled_Delay200_Checks.csv')\nendpoints = delay[delay.iteration.isin([1,200])]\ndisplay(endpoints[['gene','iteration','mfe_kcal_mol','sequence_identity','fold_identity','all_three_P2_complete','readout_mode']])\nassert len(delay)==1600 and delay.sequence_identity.all() and delay.fold_identity.all()\ncontrols = pd.read_csv(ROOT/'outputs/No_Intervention_Paired_Controls.csv')\ndisplay(controls[['gene','sequence_identity','topology_only_closure','mfe_only_closure','topology_and_mfe_closure','full_P2P3_closure']])\nprint('Paired omission readouts use the newly measured disease-state RNA; they do not fabricate a separate fold or complete intervention history.')")
    md("## Source reconciliation and interpretation\n\nThe independent comparison below preserves the original disease-state measurements while correcting execution coupling and measuring the full return endpoint. Original source artifacts remain byte-identical.\n\nWithin the supplied molecular embodiment, the complete P2/P3 recurrence differentiates and returns the shared RNA state with exact measured terminal sequence/fold/MFE identity and retained Delay checks. The separately prepared temperature and cell/tissue-fold/organoid continuations keep their own scope and evidence.")
    code("reconciliation = pd.read_csv(ROOT/'outputs/Source_Reconciliation.csv')\ndisplay(reconciliation)\nassert reconciliation.drop(columns='gene').all().all()\nprint('Original research bytes unchanged. The governing law is supplied; no replacement law or outside framework was introduced.')")
    md("## Artifact index\n\nFull source, frozen input transcripts, exact observer settings, raw fresh fold measurements, complete state/Delay records, prior source snapshots, measured summaries, and independent verification are included in the ZIP. See `QTET_mRNA_Coupled_Reversion_Results_20261008.md` and `METHOD_CORRECTION.md`.")
    notebook=nbformat.v4.new_notebook(cells=cells,metadata={"kernelspec":{"display_name":"Python 3","language":"python","name":"python3"},"language_info":{"name":"python"}})
    nbformat.validate(notebook)
    path=root/"QTET_mRNA_Coupled_Reversion_Rerun_20261008.ipynb"
    nbformat.write(notebook,path)
    print(report)
    print(path)
    return path


if __name__=="__main__":build()
