"""Execute the supplied molecular P2/P3 recurrence against one shared RNA state.

Destiny Machwaya retains authorship and all rights in the governing research.
ViennaRNA is the downstream full-transcript structural observer.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import platform
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import RNA

P2 = "3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)"
P3 = "P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]"
STATES = ("3,3", "0,0:first", "0,1", "1,2", "2,1", "1,0", "0,0:final", "Delay(200)")


def digest(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def write_json(path: Path, obj):
    temporary = path.with_suffix(path.suffix + ".partial")
    temporary.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
    temporary.replace(path)


def write_csv(path: Path, rows):
    if not rows:
        return
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


@dataclass
class P2Carrier:
    component: int
    coordinate: int
    dimension: str
    history: list = field(default_factory=list)

    def acknowledge(self, state_index):
        if self.history != list(STATES[:state_index]):
            raise ValueError(f"P2_{self.component}: incomplete or reordered P2 prefix")
        self.history.append(STATES[state_index])


@dataclass
class MolecularP3:
    row: dict
    origin: str
    carriers: list[P2Carrier]
    current: str = field(init=False)
    states: list = field(default_factory=list)
    inverse_pair: dict | None = None
    reference_epoch: str = field(init=False)

    def __post_init__(self):
        self.current = self.origin
        self.reference_epoch = digest(self.origin.replace("T", "U"))
        expected = [(i + 1, p, f"D_{i+1}") for i, p in enumerate(self.row["mrna_positions"])]
        actual = [(c.component, c.coordinate, c.dimension) for c in self.carriers]
        if actual != expected:
            raise ValueError("P3 requires all three complete, coordinate-local P2 embeddings")

    def transition(self, state_index):
        if self.states != list(STATES[:state_index]):
            raise ValueError("Shared P3 traversal is incomplete or out of order")
        if len(self.carriers) != 3:
            raise ValueError("P3 component removed")
        for carrier in self.carriers:
            if carrier.history != self.states:
                raise ValueError("P2 component decoupled from the shared P3 state")
        for carrier in self.carriers:
            carrier.acknowledge(state_index)
        state = STATES[state_index]
        event = {"state": state, "operation": "retain shared molecular state"}
        coordinate = self.carriers[1].coordinate
        index = coordinate - 1
        if state == "0,1":
            before = self.current[index]
            if before != self.row["ref"]:
                raise ValueError("Authentic differentiation source base disagrees")
            after = self.row["alt"]
            self.inverse_pair = {"coordinate": coordinate, "before": before, "after": after}
            self.current = self.current[:index] + after + self.current[index+1:]
            event.update(operation="authentic differentiation inside P2/P3", before=before, after=after, coordinate=coordinate)
        elif state == "2,1":
            if self.inverse_pair is None or self.current[index] != self.inverse_pair["after"]:
                raise ValueError("Inversion has no matching lawful differentiation history")
            # Execute the captured inverse of the 0,1 event; do not clamp a
            # reference sequence into an unrelated folding calculation.
            before = self.current[index]
            after = self.inverse_pair["before"]
            self.current = self.current[:index] + after + self.current[index+1:]
            event.update(operation="inversion-paired return inside P2/P3", before=before, after=after, coordinate=coordinate)
        self.states.append(state)
        event["all_three_complete_prefixes"] = all(c.history == self.states for c in self.carriers)
        event["reference_epoch"] = self.reference_epoch
        event["sequence_rna_sha256"] = digest(self.current.replace("T", "U"))
        return event


class WholeRNAObserver:
    def __init__(self, gene, temperature, checkpoint_dir):
        self.gene = gene
        self.temperature = temperature
        self.directory = checkpoint_dir
        self.directory.mkdir(exist_ok=True, parents=True)
        self.frames = []
        self.last = None

    def observe(self, molecule, state, fresh=False):
        rna = molecule.current.replace("T", "U")
        sha = digest(rna)
        if not fresh and self.last is not None and self.last["sequence_rna_sha256"] == sha:
            return {**self.last, "checked_at_state": state, "readout_mode": "retained measurement; live input hash verified"}
        frame_id = f"{self.gene}_{self.temperature:g}C_fold_{len(self.frames)+1}"
        checkpoint = self.directory / (frame_id + ".json")
        request = {"sequence_rna_sha256": sha, "temperature_C": self.temperature, "engine": "ViennaRNA 2.7.2", "state": state}
        if checkpoint.exists():
            frame = json.loads(checkpoint.read_text())
            if any(frame[k] != v for k, v in request.items()):
                raise ValueError("Fold checkpoint input/environment mismatch")
            print(f"RECOVER {frame_id}", flush=True)
        else:
            print(f"FOLD_BEGIN {frame_id} {state} {len(rna)}nt", flush=True)
            started = time.monotonic()
            md = RNA.md()
            md.temperature = self.temperature
            compound = RNA.fold_compound(rna, md)
            structure, energy = compound.mfe()
            frame = {**request, "frame_id": frame_id, "structure": structure, "mfe_kcal_mol": float(energy),
                     "dot_bracket_sha256": digest(structure), "runtime_seconds": time.monotonic()-started,
                     "completed_utc": datetime.now(timezone.utc).isoformat(), "full_transcript_length": len(rna)}
            write_json(checkpoint, frame)
            print(f"FOLD_END {frame_id} {float(energy):.12g} {frame['runtime_seconds']:.2f}s", flush=True)
        self.frames.append(frame)
        self.last = frame
        return {**frame, "checked_at_state": state, "readout_mode": "fresh full-transcript MFE measurement"}


def live_snapshot(molecule, observation, state_index):
    current_sha = digest(molecule.current.replace("T", "U"))
    if observation["sequence_rna_sha256"] != current_sha:
        raise ValueError("Fold observer decoupled from live shared RNA input")
    ptable = RNA.ptable(observation["structure"])
    result = []
    for carrier in molecule.carriers:
        result.append({
            "gene": molecule.row["gene"], "temperature_C": observation["temperature_C"],
            "P3_component": f"P2_{carrier.component} ⊗ {carrier.dimension}", "component_index": carrier.component,
            "mrna_coordinate": carrier.coordinate, "coding_coordinate": molecule.row["c_coordinate"] + carrier.component - 2,
            "state_index": state_index, "state": STATES[state_index],
            "base": molecule.current[carrier.coordinate-1], "reference_base": molecule.origin[carrier.coordinate-1],
            "RNA_partner_coordinate": int(ptable[carrier.coordinate]),
            "shared_molecule_sequence_rna_sha256": current_sha,
            "shared_fold_frame_id": observation["frame_id"],
            "shared_dot_bracket_sha256": observation["dot_bracket_sha256"],
            "shared_reference_epoch": molecule.reference_epoch,
            "all_three_synchronized": all(c.history == molecule.states for c in molecule.carriers),
            "complete_P2_prefix_length": len(carrier.history), "measurement_state": observation["state"],
            "readout_mode": observation["readout_mode"],
        })
    return result


def compare(current, reference, current_sequence, origin):
    return {
        "sequence_hamming_full_transcript": sum(a != b for a, b in zip(current_sequence, origin)),
        "delta_mfe_kcal_mol": current["mfe_kcal_mol"] - reference["mfe_kcal_mol"],
        "base_pair_distance": int(RNA.bp_distance(current["structure"], reference["structure"])),
        "changed_dot_bracket_positions": sum(a != b for a, b in zip(current["structure"], reference["structure"])),
        "sequence_identity": current_sequence == origin,
        "fold_identity": current["structure"] == reference["structure"],
        "mfe_identity": current["mfe_kcal_mol"] == reference["mfe_kcal_mol"],
    }


def validate_record(record):
    states = record["state_records"]
    if [s["state"] for s in states] != list(STATES):
        raise ValueError("Incomplete canonical state traversal")
    ledger = record["P3_component_ledger"]
    if len(ledger) != 24:
        raise ValueError("Three complete P2 ledgers are required")
    positions = record["input"]["mrna_positions"]
    for index, state in enumerate(states):
        rows = [r for r in ledger if r["state_index"] == index]
        if [r["component_index"] for r in rows] != [1,2,3] or [r["mrna_coordinate"] for r in rows] != positions:
            raise ValueError("Incomplete or moved P3 carrier")
        if any(r["complete_P2_prefix_length"] != index+1 or not r["all_three_synchronized"] for r in rows):
            raise ValueError("Component history decoupled")
        for key, state_key in [("shared_molecule_sequence_rna_sha256", "sequence_rna_sha256"),
                               ("shared_fold_frame_id", "fold_frame_id"),
                               ("shared_reference_epoch", "reference_epoch")]:
            if any(r[key] != state[state_key] for r in rows):
                raise ValueError("Projected carrier observation decoupled from molecular state")
    if len(record["delay_records"]) != 200 or any(r["iteration"] != i+1 for i,r in enumerate(record["delay_records"])):
        raise ValueError("Incomplete Delay(200)")
    for r in record["delay_records"]:
        if r["reference_epoch"] != states[1]["reference_epoch"] or r["all_three_P2_complete"] is not True:
            raise ValueError("Delay decoupled from complete molecular P3")
    return True


def run_lane(row, root_string, temperature):
    root = Path(root_string)
    target = root / "outputs" / f"{row['gene']}_{temperature:g}C.json"
    code_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if target.exists():
        result = json.loads(target.read_text())
        if result["runner_sha256"] != code_sha or result["input"] != row:
            raise ValueError("Completed run checkpoint does not match source lock")
        validate_record(result)
        print(f"INHERIT_COMPLETED {row['gene']} {temperature:g}C", flush=True)
        return result
    fasta = (root / "frozen_inputs" / (row["accession"] + ".reference.fasta")).read_text().splitlines()
    rna = "".join(line for line in fasta if not line.startswith(">"))
    if digest(rna) != row["reference_rna_sha256"] or len(rna) != row["length_nt"]:
        raise ValueError("Frozen sequence mismatch")
    origin = rna.replace("U", "T")
    carriers = [P2Carrier(i+1, p, f"D_{i+1}") for i,p in enumerate(row["mrna_positions"])]
    molecule = MolecularP3(row, origin, carriers)
    observer = WholeRNAObserver(row["gene"], temperature, root/"outputs"/"fold_frames")
    ledger, state_records, events, delay_records = [], [], [], []
    reference = None
    disease = None
    disease_sequence = None
    for index, state in enumerate(STATES):
        event = molecule.transition(index)
        events.append(event)
        if state == "Delay(200)":
            for iteration in range(1,201):
                obs = observer.observe(molecule, f"Delay(200):{iteration}", fresh=iteration in (1,200))
                snapshot = live_snapshot(molecule, obs, index)
                identity = compare(obs, reference, molecule.current, origin)
                delay_records.append({
                    "iteration": iteration, "sequence_rna_sha256": digest(molecule.current.replace("T","U")),
                    "fold_frame_id": obs["frame_id"], "dot_bracket_sha256": obs["dot_bracket_sha256"],
                    "mfe_kcal_mol": obs["mfe_kcal_mol"], "readout_mode": obs["readout_mode"],
                    "reference_epoch": molecule.reference_epoch,
                    "carrier_bases": [r["base"] for r in snapshot],
                    "carrier_partners": [r["RNA_partner_coordinate"] for r in snapshot],
                    "all_three_P2_complete": all(c.history == list(STATES) for c in carriers),
                    "coordinates_invariant": [c.coordinate for c in carriers] == row["mrna_positions"],
                    **identity,
                })
        else:
            obs = observer.observe(molecule, state, fresh=state in ("3,3", "0,1", "2,1"))
            snapshot = live_snapshot(molecule, obs, index)
        if state == "0,0:first":
            reference = obs
        if state == "1,2":
            disease, disease_sequence = obs, molecule.current
        record = {
            "state_index": index, "state": state, "reference_epoch": molecule.reference_epoch,
            "sequence_rna_sha256": digest(molecule.current.replace("T", "U")),
            "fold_frame_id": obs["frame_id"], "dot_bracket_sha256": obs["dot_bracket_sha256"],
            "mfe_kcal_mol": obs["mfe_kcal_mol"], "measurement_state": obs["state"],
            "readout_mode": obs["readout_mode"],
            "triplet": "".join(molecule.current[p-1] for p in row["mrna_positions"]),
            "component_partners": [s["RNA_partner_coordinate"] for s in snapshot],
            "all_three_synchronized": event["all_three_complete_prefixes"],
        }
        if reference is not None:
            record["comparison_to_reference"] = compare(obs, reference, molecule.current, origin)
        state_records.append(record)
        ledger.extend(snapshot)
    returned = compare(obs, reference, molecule.current, origin)
    disease_comparison = compare(disease, reference, disease_sequence, origin)
    delay_pass = all(r["sequence_identity"] and r["fold_identity"] and r["mfe_identity"] and r["all_three_P2_complete"] and r["coordinates_invariant"] for r in delay_records)
    result = {
        "schema": "qtet-coupled-molecular-p2p3-rerun/v1", "author_rights_holder": "Destiny Machwaya",
        "governing_law_status": "supplied; invariant operator and law preserved",
        "canonical_tensor_p2": P2, "canonical_tensor_p3": P3, "input": row,
        "runner_sha256": code_sha, "temperature_C": temperature,
        "started_from": "frozen full-transcript RNA; three complete coordinate-local P2 embeddings",
        "operation_source": "Source panel cell 10 / prepared v3 cell 5; inversion-paired authentic differentiation-return",
        "coupling": "All component transitions, molecular operations, observer inputs, and projected partner readouts share one state, reference epoch, and RNA molecule. Whole-transcript energy is never divided into independent P2 energies.",
        "events": events, "state_records": state_records, "P3_component_ledger": ledger,
        "delay_records": delay_records, "fold_measurements": observer.frames,
        "disease_measurement": disease_comparison, "returned_measurement": returned,
        "validation": {"complete_P2P3": True, "canonical_history": molecule.states == list(STATES),
                       "sequence_return": returned["sequence_identity"], "fold_return": returned["fold_identity"],
                       "mfe_return": returned["mfe_identity"], "Delay200": delay_pass},
        "delay_implementation": "200 live shared-state invariance checks; independent full-transcript refolds at checks 1 and 200; no invented physical time units or independent evolved trajectories",
        "engine": {"version": RNA.__version__, "python": platform.python_version(), "temperature_C": temperature,
                   "role": "downstream full-transcript structural readout", "stochastic_seed": None},
        "completed_utc": datetime.now(timezone.utc).isoformat(),
    }
    validate_record(result)
    write_json(target, result)
    print(f"LANE_COMPLETE {row['gene']} {temperature:g}C {result['validation']}", flush=True)
    return result


def summarize(results, root):
    summary, ledger, trajectory, delay, controls = [], [], [], [], []
    for r in results:
        gene, temp = r["input"]["gene"], r["temperature_C"]
        d, x = r["disease_measurement"], r["returned_measurement"]
        summary.append({"gene": gene, "accession": r["input"]["accession"], "temperature_C": temp,
                        "length_nt": r["input"]["length_nt"], "mrna_center": r["input"]["mrna_positions"][1],
                        "reference_triplet": r["input"]["reference_triplet"],
                        "disease_delta_mfe_kcal_mol": d["delta_mfe_kcal_mol"],
                        "return_delta_mfe_kcal_mol": x["delta_mfe_kcal_mol"],
                        "disease_base_pair_distance": d["base_pair_distance"],
                        "return_base_pair_distance": x["base_pair_distance"],
                        "disease_changed_dot_bracket_positions": d["changed_dot_bracket_positions"],
                        "return_changed_dot_bracket_positions": x["changed_dot_bracket_positions"],
                        "disease_sequence_hamming": d["sequence_hamming_full_transcript"],
                        "return_sequence_hamming": x["sequence_hamming_full_transcript"],
                        **r["validation"], "fresh_full_transcript_folds": len(r["fold_measurements"]),
                        "complete_P2_ledgers": 3, "state_rows": len(r["P3_component_ledger"]), "Delay_checks": len(r["delay_records"])})
        ledger.extend(r["P3_component_ledger"])
        for s in r["state_records"]:
            c=s.get("comparison_to_reference",{})
            trajectory.append({"gene":gene,"temperature_C":temp,"state_index":s["state_index"],"state":s["state"],
                               "triplet":s["triplet"],"mfe_kcal_mol":s["mfe_kcal_mol"],
                               "delta_mfe_kcal_mol":c.get("delta_mfe_kcal_mol"),"base_pair_distance":c.get("base_pair_distance"),
                               "sequence_hamming":c.get("sequence_hamming_full_transcript"),
                               "shared_sequence_rna_sha256":s["sequence_rna_sha256"],"shared_fold_frame_id":s["fold_frame_id"],
                               "all_three_synchronized":s["all_three_synchronized"],"readout_mode":s["readout_mode"]})
        for p in r["delay_records"]:
            delay.append({"gene":gene,"temperature_C":temp,**{k:v for k,v in p.items() if k not in ("carrier_bases","carrier_partners")},
                          "carrier_bases":"|".join(p["carrier_bases"]),"carrier_partners":"|".join(map(str,p["carrier_partners"]))})
        controls.append({"gene":gene,"temperature_C":temp,"control":"intervention omitted; measured disease-state held",
                         "observation_basis":"paired newly measured 1,2 disease input; no invented fold",
                         "sequence_identity":d["sequence_identity"],"topology_only_closure":d["fold_identity"],
                         "mfe_only_closure":d["mfe_identity"],"topology_and_mfe_closure":d["fold_identity"] and d["mfe_identity"],
                         "canonical_intervention_executed":False,"full_P2P3_closure":False})
    for name,rows in [("Coupled_Reversion_Summary.csv",summary),("Complete_P2P3_State_Ledgers.csv",ledger),
                      ("Joint_Molecular_State_Trajectories.csv",trajectory),("Coupled_Delay200_Checks.csv",delay),
                      ("No_Intervention_Paired_Controls.csv",controls)]:
        write_csv(root/"outputs"/name,rows)
    return summary


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--root",type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument("--temperatures",nargs="+",type=float,default=[37.0])
    parser.add_argument("--workers",type=int,default=3)
    parser.add_argument("--genes",nargs="+")
    args=parser.parse_args()
    if RNA.__version__!="2.7.2": raise ValueError("Use the source-pinned ViennaRNA 2.7.2")
    root=args.root.resolve();(root/"outputs").mkdir(exist_ok=True)
    rows=json.loads((root/"frozen_inputs/panel.json").read_text())
    if args.genes: rows=[r for r in rows if r["gene"] in args.genes]
    futures={};results=[];failures=[]
    started=datetime.now(timezone.utc).isoformat()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for row in sorted(rows,key=lambda r:r["length_nt"],reverse=True):
            for temp in args.temperatures:
                futures[pool.submit(run_lane,row,str(root),temp)]=(row["gene"],temp)
        for future in as_completed(futures):
            key=futures[future]
            try:results.append(future.result())
            except Exception as exc:
                failures.append({"gene":key[0],"temperature_C":key[1],"exception":repr(exc)})
                print("LANE_ERROR",key,repr(exc),flush=True)
            ordered=sorted(results,key=lambda r:(r["temperature_C"],next(i for i,x in enumerate(rows) if x["gene"]==r["input"]["gene"])))
            summarize(ordered,root)
            write_json(root/"outputs/run_status.json",{"started_utc":started,"completed_lanes":len(results),"requested_lanes":len(futures),"failures":failures,"complete":len(results)==len(futures)})
    if failures: raise RuntimeError(f"{len(failures)} RNA lanes failed; checkpoints retained")
    print("RERUN_COMPLETE",len(results),"lanes",flush=True)


if __name__=="__main__": main()
