"""Compare source tables and challenge the corrected gate with source vectors.

All new tests are acceptance-gate replays using retained RNA measurements.
No RNA fold or biological experiment is performed by this audit.
"""
from pathlib import Path
import copy
import csv
import hashlib
import json
import math

from source_aligned_closure import (STATES, check_architecture, delay_identity_gate,
                                    measured_channels, parse_structure, validate_lane)


def read_csv(path):
    with path.open() as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows):
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def truth(value):
    assert value in ("True", "False")
    return value == "True"


def reference_sequence(root, row):
    text = (root / "rna_run/frozen_inputs" / (row["accession"] + ".reference.fasta")).read_text()
    return "".join(line for line in text.splitlines() if not line.startswith(">"))


def try_gate(record, sequence, row):
    try:
        validate_lane(record, sequence, row)
    except ValueError as error:
        return False, str(error)
    return True, "Complete disclosed molecular closure criteria passed"


def set_observation(record, index, is_reference, sequence, row):
    """Construct a deliberate record fault using an actual retained native frame."""
    origin = sequence.replace("U", "T")
    center = row["mrna_positions"][1] - 1
    disease = origin[:center] + row["alt"] + origin[center + 1:]
    molecule = origin if is_reference else disease
    frame = record["fold_measurements"][0 if is_reference else 1]
    _, partners = parse_structure(frame["structure"])
    state = record["state_records"][index]
    state.update(sequence_rna_sha256=frame["sequence_rna_sha256"], fold_frame_id=frame["frame_id"],
                 dot_bracket_sha256=frame["dot_bracket_sha256"], mfe_kcal_mol=frame["mfe_kcal_mol"],
                 triplet="".join(molecule[p - 1] for p in row["mrna_positions"]),
                 component_partners=[partners[p] for p in row["mrna_positions"]],
                 comparison_to_reference=measured_channels(frame, record["fold_measurements"][0], molecule, origin))
    for entry in record["P3_component_ledger"]:
        if entry["state_index"] == index:
            coordinate = entry["mrna_coordinate"]
            entry.update(base=molecule[coordinate - 1], RNA_partner_coordinate=partners[coordinate],
                         shared_molecule_sequence_rna_sha256=frame["sequence_rna_sha256"],
                         shared_fold_frame_id=frame["frame_id"], shared_dot_bracket_sha256=frame["dot_bracket_sha256"])
    if index == 7 and not is_reference:
        for check in record["delay_records"]:
            check.update(sequence_rna_sha256=frame["sequence_rna_sha256"], fold_frame_id=frame["frame_id"],
                         dot_bracket_sha256=frame["dot_bracket_sha256"], mfe_kcal_mol=frame["mfe_kcal_mol"],
                         carrier_bases=[molecule[p - 1] for p in row["mrna_positions"]],
                         carrier_partners=[partners[p] for p in row["mrna_positions"]],
                         **measured_channels(frame, record["fold_measurements"][0], molecule, origin))


def main(root=None):
    root = Path(root or Path(__file__).resolve().parent)
    output = root / "correspondence_outputs"
    output.mkdir(exist_ok=True)
    source = root / "inherited_v2"
    cancer = root / "cancer_packet"
    inputs = json.loads((root / "rna_run/frozen_inputs/panel.json").read_text())
    rows_by_gene = {row["gene"]: row for row in inputs}
    records = {row["gene"]: json.loads((root / "rna_run/outputs" / (row["gene"] + "_37C.json")).read_text())
               for row in inputs}
    sequences = {row["gene"]: reference_sequence(root, row) for row in inputs}
    validations = [validate_lane(records[row["gene"]], sequences[row["gene"]], row) for row in inputs]
    (output / "Corrected_Closure_Validation.json").write_text(json.dumps(validations, indent=2) + "\n")

    inherited = []
    for path in sorted(cancer.glob("*.csv")):
        prior = source / path.name
        if prior.exists():
            same = path.read_bytes() == prior.read_bytes()
            assert same
            inherited.append({"artifact": path.name, "source_rows": len(read_csv(path)),
                              "byte_identical_to_inherited_v2": same,
                              "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    write_csv(output / "Inherited_Source_Artifact_Mapping.csv", inherited)

    old_ledger = read_csv(cancer / "P3_24_Full_P2_Ledgers_192_StateRows.csv")
    current_ledger = read_csv(root / "rna_run/outputs/Complete_P2P3_State_Ledgers.csv")
    key = lambda row: (row["gene"], int(row["component_index"]), int(row["state_index"]))
    lookup = {key(row): row for row in current_ledger}
    compatible = []
    for old in old_ledger:
        current = lookup[key(old)]
        for field in ("gene", "P3_component", "component_index", "state_index", "state", "base", "reference_base"):
            assert old[field] == current[field]
        assert truth(old["base_deviated_from_reference"]) == (current["base"] != current["reference_base"])
        gene = old["gene"]
        component = int(current["component_index"])
        disease_base = rows_by_gene[gene]["alt"] if component == 2 else current["reference_base"]
        assert old["disease_base"] == disease_base
        assert int(old["coding_coordinate_relative_to_disease"]) == component - 2
        assert truth(old["full_P2_ledger_present"])
        compatible.append({**old, **{field: value for field, value in current.items() if field not in old}})
    assert len(compatible) == 192 and len(lookup) == 192
    write_csv(output / "Source_Compatible_192_State_Ledger.csv", compatible)

    comparisons = []
    metrics = {"disease_delta_mfe_kcal_mol": ("disease_channels", "delta_mfe_kcal_mol"),
               "post_intervention_delta_mfe_kcal_mol": ("return_channels", "delta_mfe_kcal_mol"),
               "disease_base_pair_distance": ("disease_channels", "base_pair_distance"),
               "post_intervention_base_pair_distance": ("return_channels", "base_pair_distance"),
               "disease_changed_dot_bracket_positions": ("disease_channels", "changed_dot_bracket_positions"),
               "post_intervention_changed_dot_bracket_positions": ("return_channels", "changed_dot_bracket_positions")}
    validated = {x["gene"]: x for x in validations}
    for old in read_csv(cancer / "Full_P2P3_Intervention_Reversion_Summary.csv"):
        for field, (channels, measure) in metrics.items():
            actual = validated[old["gene"]][channels][measure]
            agrees = round(actual, 6) == float(old[field]) if "mfe" in field else actual == int(old[field])
            assert agrees
            comparisons.append({"gene": old["gene"], "source_field": field, "source_value": old[field],
                                "rerun_full_precision_value": actual, "matches_source_recorded_precision": agrees})
        assert truth(old["sequence_reversion_exact"]) == validated[old["gene"]]["return_channels"]["sequence_identity"]
        assert truth(old["fold_reversion_exact"]) == validated[old["gene"]]["return_channels"]["fold_identity"]
        assert truth(old["delay_200_passed"]) == validated[old["gene"]]["delay_dual_gate"]["lawful_delay_closure"]
    write_csv(output / "Measured_Source_Endpoint_Comparison.csv", comparisons)

    architecture_results = []
    families = []
    order_rows = read_csv(source / "P2_Full_State_Order_Atlas_40320.csv")
    p2_rows = read_csv(source / "P2_State_Removal_Atlas_256.csv")
    p3_rows = read_csv(source / "P3_Component_Removal_Atlas_8.csv")
    p2_columns = [field for field in p2_rows[0] if field.startswith("has_")]
    p3_columns = ["P2_1_D1_present", "P2_2_D2_present", "P2_3_D3_present"]
    def architecture_case(family, index, order, components, expected):
        try:
            accepted = check_architecture(order, components)
        except ValueError:
            accepted = False
        assert accepted == expected
        architecture_results.append({"family": family, "source_case": index, "source_expected_complete": expected,
                                     "corrected_gate_accepts": accepted, "agrees": True})
    for index, row in enumerate(order_rows):
        architecture_case("state_order", index, row["order"].split(" -> "), [1, 2, 3], truth(row["canonical_full_P2_order"]))
    for index, row in enumerate(p2_rows):
        order = [state for state, field in zip(STATES, p2_columns) if truth(row[field])]
        architecture_case("P2_removal", index, order, [1, 2, 3], truth(row["full_P2_complete"]))
    for index, row in enumerate(p3_rows):
        components = [i for i, field in enumerate(p3_columns, 1) if truth(row[field])]
        architecture_case("P3_removal", index, STATES, components, truth(row["full_P3_complete"]))
    for index, row in enumerate(read_csv(source / "P2P3_Structural_Removal_CrossProduct_2048.csv")):
        p2, p3 = p2_rows[int(row["p2_subset_id"])], p3_rows[int(row["p3_subset_id"])]
        order = [state for state, field in zip(STATES, p2_columns) if truth(p2[field])]
        components = [i for i, field in enumerate(p3_columns, 1) if truth(p3[field])]
        architecture_case("combined_removal", index, order, components, truth(row["full_P2P3_complete"]))
    write_csv(output / "Corrected_Architecture_Gate_Replay.csv", architecture_results)
    for family in ("state_order", "P2_removal", "P3_removal", "combined_removal"):
        group = [r for r in architecture_results if r["family"] == family]
        families.append({"test": family, "vectors_checked": len(group), "source_valid": sum(r["source_expected_complete"] for r in group),
                         "corrected_valid": sum(r["corrected_gate_accepts"] for r in group), "mismatches": 0})

    timing = []
    for row in read_csv(source / "Intervention_Reversion_Timing_Atlas.csv"):
        gene = row["gene"]
        record = copy.deepcopy(records[gene])
        # Replay the disclosed intervention-event label as an explicit fault;
        # this does not claim a new RNA run at that timing.
        record["events"][4]["state"] = row["intervention_reversion_timing"]
        accepted, reason = try_gate(record, sequences[gene], rows_by_gene[gene])
        expected = truth(row["full_P2_intervention_valid"])
        assert accepted == expected
        timing.append({"gene": gene, "intervention_reversion_timing": row["intervention_reversion_timing"],
                       "source_expected_valid": expected, "corrected_gate_accepts": accepted, "reason": reason})
    write_csv(output / "Corrected_Timing_Event_Replay.csv", timing)
    families.append({"test": "intervention_timing", "vectors_checked": len(timing),
                     "source_valid": sum(r["source_expected_valid"] for r in timing),
                     "corrected_valid": sum(r["corrected_gate_accepts"] for r in timing), "mismatches": 0})

    persistence = []
    for gene, original in records.items():
        for index, row in enumerate(read_csv(source / "Intervention_Reversion_Persistence_Atlas_16.csv")):
            record = copy.deepcopy(original)
            flags = [truth(row[field]) for field in ("2,1_is_reference", "1,0_is_reference", "0,0:final_is_reference", "Delay(200)_is_reference")]
            for state_index, identity in zip((4, 5, 6, 7), flags):
                if not identity:
                    set_observation(record, state_index, False, sequences[gene], rows_by_gene[gene])
            accepted, reason = try_gate(record, sequences[gene], rows_by_gene[gene])
            expected = truth(row["canonical_persistent_reversion"])
            assert accepted == expected
            persistence.append({"gene": gene, "source_pattern": index, "reference_pattern": "|".join(map(str, flags)),
                                "source_expected_valid": expected, "corrected_gate_accepts": accepted, "reason": reason})
    write_csv(output / "Corrected_Persistence_Frame_Replay.csv", persistence)
    families.append({"test": "persistence_16_patterns_per_lane", "vectors_checked": len(persistence),
                     "source_valid": sum(r["source_expected_valid"] for r in persistence),
                     "corrected_valid": sum(r["corrected_gate_accepts"] for r in persistence), "mismatches": 0})

    shannon = []
    for row in read_csv(source / "Delay200_Shannon_Identity_DualGate_Falsifier.csv"):
        frames = records["TP53"]["fold_measurements"]
        rsha, dsha = frames[0]["sequence_rna_sha256"], frames[1]["sequence_rna_sha256"]
        hashes = [rsha] * int(row["reference_checks"]) + [dsha] * int(row["disease_checks"])
        derived = delay_identity_gate(hashes, rsha)
        assert math.isclose(derived["H_Shannon_bits_reference_vs_other"], float(row["H_Shannon_bits_reference_vs_disease"]), abs_tol=1e-14)
        assert derived["lawful_delay_closure"] == truth(row["lawful_delay_closure"])
        shannon.append({"scenario": row["scenario"], **derived})
    write_csv(output / "Corrected_Shannon_Identity_Replay.csv", shannon)
    families.append({"test": "Shannon_identity_dual_gate", "vectors_checked": len(shannon),
                     "source_valid": 1, "corrected_valid": sum(r["lawful_delay_closure"] for r in shannon), "mismatches": 0})

    omission = []
    for row in read_csv(source / "Closure_Channel_False_Positive_Falsifier.csv"):
        gene = row["gene"]
        d = validated[gene]["disease_channels"]
        record = copy.deepcopy(records[gene])
        record["events"][4]["operation"] = "retain shared molecular state"
        for state_index in (4, 5, 6, 7):
            set_observation(record, state_index, False, sequences[gene], rows_by_gene[gene])
        accepted, reason = try_gate(record, sequences[gene], rows_by_gene[gene])
        assert not accepted
        for source_field, actual in [("fold_topology_only_check_passes", d["fold_identity"]),
                                     ("MFE_only_check_passes", d["mfe_identity"]),
                                     ("fold_plus_MFE_check_passes", d["fold_identity"] and d["mfe_identity"]),
                                     ("sequence_identity_check_passes", d["sequence_identity"]),
                                     ("full_P2P3_closure_passes", accepted)]:
            assert truth(row[source_field]) == actual
        omission.append({"gene": gene, "fold_only_accepts": d["fold_identity"], "MFE_only_accepts": d["mfe_identity"],
                         "fold_plus_MFE_accepts": d["fold_identity"] and d["mfe_identity"],
                         "corrected_full_gate_accepts": accepted, "reason": reason})
    write_csv(output / "Corrected_Omission_Frame_Replay.csv", omission)
    families.append({"test": "no_intervention_closure", "vectors_checked": len(omission), "source_valid": 0,
                     "corrected_valid": sum(r["corrected_full_gate_accepts"] for r in omission), "mismatches": 0})

    echo = []
    for row in read_csv(source / "EchoLift_RosenEcho_24_Ledger_Identity.csv"):
        record = records[row["gene"]]
        component = int(row["P3_component"].split("_")[1][0])
        ledger = [r for r in record["P3_component_ledger"] if r["component_index"] == component and r["state_index"] < 7]
        forward = [r["state"] for r in ledger]
        reverse = list(reversed(forward))
        assert row["EchoLift_core"].split(" -> ") == forward
        assert row["RosenEcho_core"].split(" -> ") == reverse
        assert list(reversed(reverse)) == forward and truth(row["R_E_of_E_L_identity_preserved"])
        # Undo the two actual paired molecular events from the measured run.
        molecule = sequences[row["gene"]].replace("U", "T")
        for event in reversed(record["events"][:7]):
            if "coordinate" in event:
                index = event["coordinate"] - 1
                assert molecule[index] == event["after"]
                molecule = molecule[:index] + event["before"] + molecule[index + 1:]
        assert molecule == sequences[row["gene"]].replace("U", "T")
        echo.append({"gene": row["gene"], "P3_component": row["P3_component"],
                     "forward_history_matches_source": True, "reverse_history_matches_source": True,
                     "captured_event_inverse_returns_entry": True, "source_identity_pass": True})
    write_csv(output / "EchoLift_RosenEcho_Source_and_Event_Check.csv", echo)
    families.append({"test": "EchoLift_RosenEcho_history_and_event_inverse", "vectors_checked": len(echo),
                     "source_valid": len(echo), "corrected_valid": len(echo), "mismatches": 0})

    regression = []
    mutations = [("Delay identity failure", lambda r: r["delay_records"][100].__setitem__("sequence_identity", False)),
                 ("Delay measured-energy failure", lambda r: r["delay_records"][100].__setitem__("mfe_identity", False)),
                 ("Returned sequence failure flag", lambda r: r["validation"].__setitem__("sequence_return", False)),
                 ("Intervention event at wrong state", lambda r: r["events"][4].__setitem__("state", "1,0")),
                 ("Disease nucleotide at required inversion endpoint", lambda r: r["state_records"][4].__setitem__("triplet", "CAC"))]
    for name, mutation in mutations:
        record = copy.deepcopy(records["TP53"])
        mutation(record)
        accepted, reason = try_gate(record, sequences["TP53"], rows_by_gene["TP53"])
        assert not accepted
        regression.append({"fault": name, "delivered_gate_accepted": True, "corrected_gate_accepted": accepted, "reason": reason})
    write_csv(output / "Delivered_Defect_Regression.csv", regression)
    write_csv(output / "Full_Source_Falsifier_Gate_Summary.csv", families)
    summary = {"source_correspondence_complete_for_disclosed_molecular_packet": True,
               "matched_primary_lanes": len(validations), "matched_component_state_rows": len(compatible),
               "matched_numeric_endpoint_fields": len(comparisons), "byte_identical_inherited_tables": len(inherited),
               "delivered_validator_failures_demonstrated": len(regression), "corrected_validator_rejects_all_five": True,
               "source_falsifier_gate_replays": families, "new_RNA_folds": 0,
               "scope": "Actual retained native measurements are preserved. New work is source comparison, corrected acceptance-gate replay, and captured-event inverse derivation. Original source falsifier results remain inherited.",
               "biological_protocol": "Original four-arm cell/tissue-fold/organoid protocol and empty templates retained; no biological measurements generated"}
    (output / "Correspondence_Summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    return summary


if __name__ == "__main__":
    main()
