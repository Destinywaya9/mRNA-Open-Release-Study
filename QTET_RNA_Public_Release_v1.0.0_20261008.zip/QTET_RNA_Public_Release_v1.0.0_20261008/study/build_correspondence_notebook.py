"""Build and execute the source-correspondence review without new RNA folds."""
from pathlib import Path
import csv
import json
import re
import sys
import nbformat
from nbconvert import HTMLExporter


def table(rows, fields):
    return "\n".join(["| " + " | ".join(fields) + " |",
                      "| " + " | ".join(["---"] * len(fields)) + " |"]
                     + ["| " + " | ".join(str(row[field]) for field in fields) + " |" for row in rows])


def main():
    root = Path(__file__).resolve().parent
    summary = json.loads((root / "correspondence_outputs/Correspondence_Summary.json").read_text())
    families = summary["source_falsifier_gate_replays"]
    report = """# RNA reversion source correspondence and execution correction

The attached packages agree on the eight measured molecular lanes and all 192 carrier/base/state rows. The assistant-produced runner did not enforce the cancer packet's complete acceptance criteria. Its delivered validator accepted five deliberately incorrect records, including an intervention event at the wrong state, failed Delay identities, and a nonreference triplet at the required inversion endpoint. The earlier assurance of a complete execution correction was too broad.

The original research, supplied governing law, Tensor P2/P3, authentic transcript versions, and recorded results remain unchanged. Research author and rights holder: Destiny Machwaya.

## Direct source comparison

The cancer packet's research brief, section 3, defines authentic differentiation at `0,1`, disease readout at `1,2`, authentic disease/reference intervention reversion at `2,1`, return verification at `1,0`, terminal `0,0`, and post-return Delay(200). Its executed v2 notebook adds full order/removal, timing, persistence, closure-channel, Shannon/identity, and EchoLift/RosenEcho audits.

The rerun retains the same authentic inverse nucleotide operation and performs native full-transcript observations. All eight disease MFE differences, base-pair distances, changed-position counts, and return residuals agree with the cancer packet at its recorded precision: 48 numerical comparisons, plus exact sequence/fold/Delay return agreement in eight lanes. All 192 source carrier/base/state rows also agree, including both unchanged flanks.

Nine CSVs originally shared by the two attached packages are byte-identical inside the rerun's inherited v2 ZIP. The continuation makes those tables visible and also recovers four existing dependencies referenced by the cancer packet's output-bearing notebook: the whole-state trajectory, saved key counts, P2 removal atlas, and P3 removal atlas. No source table is regenerated to replace the inherited result.

## Demonstrated defect and correction

The delivered `validate_record` checked order, component counts, prefix lengths, and selected provenance fields. It did not validate the event state, authentic before/after nucleotide pair, current triplet, measured identity/energy flags during Delay, or reported return-pass flags against the full source criteria. The five faults are recorded in `Delivered_Validator_Findings.json` and `correspondence_outputs/Delivered_Defect_Regression.csv`.

The corrected acceptance entry point is `source_aligned_runner.py`. It validates saved runs before inheritance and validates any missing authorized lane after execution. Its `source_aligned_closure.py` gate reconstructs the source-declared molecular history from frozen inputs, verifies events and measured frames, independently parses all partners, compares observed bases and full-transcript channels, checks every Delay record, derives the identity/Shannon dual gate, and rejects pass flags that disagree with the data. The retained measurement-producing executable and all native outputs remain byte-identical for provenance.

This correction does not add a new law, change an operator, assign physical time units, or turn the RNA observer into the governing mathematics. It enforces the criteria already supplied in the research packet.

## Complete source falsifier correspondence

The new tests below replay the inherited source vectors through the corrected acceptance gate. Timing tests challenge event labels; persistence and omitted-intervention tests use the retained native reference/disease frames. They are software validation and source comparison, not additional RNA folding measurements or biological experiments.

""" + table(families, ["test", "vectors_checked", "source_valid", "corrected_valid", "mismatches"]) + """

All five faults accepted by the delivered validator are rejected by the corrected gate. The eight intact measured runs pass. The no-intervention weak channels retain their original false-positive counts: fold-only 4/8, MFE-only 2/8, fold-plus-MFE 2/8, complete closure 0/8. Zero Shannon entropy with the wrong molecular identity is rejected. EchoLift/RosenEcho checks preserve all 24 directional histories and derive inverse-event return from the retained molecular operations.

## Preserved study and continuation

The 40 native RNA measurements, 24 complete P2 ledgers, 192 component state rows, and 1,600 Delay checks are retained. This corrective audit performs zero new RNA folds. The source-compatible ledger restores the original pathology, variant, disease-base, role, and completeness fields alongside the rerun's molecular observation bindings.

The cancer packet's primary focus remains TP53 R175H; the other seven lanes remain its cross-pathology robustness set. Its four-arm preclinical protocol, biological continuation, and empty measurement templates are preserved exactly. No biological measurement rows are generated here.

The proper correspondence claim is now specific: the native molecular measurements and complete disclosed source criteria agree, and the corrected acceptance gate is checked against the source falsifiers. The earlier validator and its limited seven-fault report remain historical artifacts rather than evidence that the complete gate had already been enforced.

## Review and reproduce

Open `QTET_RNA_Source_Correspondence_20261008.ipynb` or its HTML preview. Run `python source_aligned_runner.py` for corrected acceptance of retained data, and `python verify_source_correspondence.py` for the complete source comparison and falsifier replay. Neither command repeats a native RNA fold with the included completed data. Original source artifacts are in `cancer_packet/`, `inherited_v2/`, and `rna_run/`; new audit outputs are in `correspondence_outputs/`.
"""
    (root / "QTET_RNA_Source_Correspondence_20261008.md").write_text(report)
    (root / "README.md").write_text("""# QTET RNA reversion source correspondence continuation

Research author and rights holder: Destiny Machwaya. Supplied law and mathematics preserved.

Start with QTET_RNA_Source_Correspondence_20261008.md. The continuation corrects a demonstrated acceptance-gate defect in the assistant-produced rerun. It preserves all native measurements and all original source artifacts. The earlier validator is retained in rna_run/ as the unchanged producer/provenance record; use source_aligned_runner.py as the corrected entry point.

`python source_aligned_runner.py` validates all eight retained lanes against the full disclosed source criteria before accepting cached results. `python verify_source_correspondence.py` compares the complete source tables and replays the source falsifier vectors. Neither repeats RNA folds with the included data. Only the explicit --execute-missing option can execute a missing originally authorized baseline lane.

The executed correspondence notebook and HTML contain the full comparison, demonstrated defects, complete falsifier counts, and exact source mapping. Original native observations and their executed notebook remain in rna_run/. The complete cancer packet is preserved in cancer_packet/ with four previously archived dependencies added to its continuation copy. All inherited v2 files remain in inherited_v2/. Original attached archive hashes and per-file preservation checks are recorded in Provenance_QA.json. SHA256SUMS.txt records the completed package.

The supplied molecular intervention definition is preserved. Original preclinical templates remain empty; no biological results are generated. No source research artifact or original recorded result is overwritten.
""")
    cells = []
    def md(text):
        cells.append(nbformat.v4.new_markdown_cell(text))
    def code(text):
        cells.append(nbformat.v4.new_code_cell(text))
    md("# QTET RNA reversion source correspondence\n\nResearch author and rights holder: **Destiny Machwaya**. The supplied law and full P2/P3 architecture are preserved. This notebook records a correction to the assistant-produced executable's acceptance gate.")
    md("## tl;dr\n\nThe eight molecular measurements and all 192 carrier/base/state rows agree with the cancer packet. The delivered runtime validator accepted five deliberately wrong records. The corrected gate rejects those five faults, accepts all eight intact measured runs, and agrees with the full disclosed source falsifiers. **No new RNA folds are performed by this audit.**")
    md("## Context & Methods\n\nThe actual attached cancer packet controls the comparison. Its molecular operation is authentic pathogenic differentiation at `0,1`, disease hold at `1,2`, intervention reversion at `2,1`, return verification, final `0,0`, and Delay(200).\n\n`Tensor P2 = 3,3 / 0,0 / 0,1 / 1,2 / 2,1 / 1,0 / 0,0 / Delay(200)`\n\n`P3 = [P2_1 ⊗ D_1, P2_2 ⊗ D_2, P2_3 ⊗ D_3]`\n\nFrozen native RNA outputs remain unchanged. Source vectors challenge the corrected gate; they are not counted as new RNA measurements. Run from the unpacked continuation folder. Install `rna_run/requirements.txt` for notebook dependencies if needed.")
    code("from pathlib import Path\nimport json, io, contextlib\nimport pandas as pd\nfrom IPython.display import display\npd.options.display.max_colwidth = None\nROOT = Path.cwd()\nassert (ROOT/'rna_run/frozen_inputs/panel.json').is_file()\nprint('Source packet, native measurements, and full original falsifier tables recovered.')")
    md("## Data\n\nThe comparison retains the exact source cancer packet, the native rerun outputs, and the complete inherited v2 archive. The source-compatible ledger keeps original metadata and the measured molecule/frame bindings together.")
    code("from verify_source_correspondence import main as verify\nwith contextlib.redirect_stdout(io.StringIO()):\n    summary = verify(ROOT)\nprint('Matched lanes:',summary['matched_primary_lanes'])\nprint('Matched component/base/state rows:',summary['matched_component_state_rows'])\nprint('Matched numeric endpoint fields:',summary['matched_numeric_endpoint_fields'])\nprint('Native RNA folds repeated by this audit:',summary['new_RNA_folds'])")
    md("## Results\n\n### Demonstrated acceptance failures\n\nThese five deliberately incorrect records passed the delivered validator. The corrected gate derives the necessary identities and checks the actual events, rather than trusting the pass flags.")
    code("regression = pd.read_csv(ROOT/'correspondence_outputs/Delivered_Defect_Regression.csv')\ndisplay(regression.rename(columns={'fault':'Failure tested','delivered_gate_accepted':'Old accepted','corrected_gate_accepted':'Corrected accepted','reason':'Rejection reason'}))\nassert not regression.corrected_gate_accepted.any()")
    md("### Complete source falsifier mapping\n\nOrder/removal vectors are checked through the same architecture function used by the corrected full-data gate. Timing labels and measured-frame persistence faults are checked with the full gate. The 16 inherited persistence patterns are applied to each of the eight measured lanes.")
    code("falsifiers = pd.read_csv(ROOT/'correspondence_outputs/Full_Source_Falsifier_Gate_Summary.csv')\nlabels = {'state_order':'P2 order','P2_removal':'P2 removal','P3_removal':'P3 removal','combined_removal':'Combined removal','intervention_timing':'Intervention timing','persistence_16_patterns_per_lane':'Persistence across eight lanes','Shannon_identity_dual_gate':'Shannon and identity','no_intervention_closure':'Omitted intervention','EchoLift_RosenEcho_history_and_event_inverse':'EchoLift and RosenEcho'}\nreadable = falsifiers.assign(test=falsifiers.test.map(labels)).rename(columns={'test':'Source test','vectors_checked':'Cases checked','source_valid':'Source valid','corrected_valid':'Corrected valid','mismatches':'Disagreements'})\ndisplay(readable)\nassert falsifiers.mismatches.sum()==0\nassert falsifiers.source_valid.equals(falsifiers.corrected_valid)")
    md("### Native RNA measurement agreement\n\nTP53 R175H remains the cancer-facing focal lane. All eight source lanes are retained. Raw full-precision values are compared at the source table's recorded six-decimal precision; pair and changed-position distances are compared exactly.")
    code("comparisons = pd.read_csv(ROOT/'correspondence_outputs/Measured_Source_Endpoint_Comparison.csv')\ngenes = [r['gene'] for r in json.loads((ROOT/'rna_run/frozen_inputs/panel.json').read_text())]\nvalues = comparisons.pivot(index='gene',columns='source_field',values='rerun_full_precision_value').reindex(genes)\nfields = ['disease_delta_mfe_kcal_mol','post_intervention_delta_mfe_kcal_mol','disease_base_pair_distance','post_intervention_base_pair_distance','disease_changed_dot_bracket_positions','post_intervention_changed_dot_bracket_positions']\nlabels = ['Disease ΔMFE (kcal/mol)','Return ΔMFE (kcal/mol)','Disease pair distance','Return pair distance','Disease changed positions','Return changed positions']\nreadable = values[fields].copy()\nfor field in fields[:2]: readable[field] = readable[field].map(lambda x: format(x,'.6f'))\nfor field in fields[2:]: readable[field] = readable[field].astype(int)\nreadable.columns = labels\ndisplay(readable)\nassert comparisons.matches_source_recorded_precision.all()\nprint('Exact sequence, fold, and Delay identity preserved in all eight measured lanes.')")
    md("### Inherited artifacts and complete P3 ledger\n\nOriginal tables stay byte-identical. The source-compatible ledger also retains the rerun's hashes, coordinates, native frame references, and observed pairing partners. Each component has its complete traversal, including the unchanged flanks.")
    code("mapping = pd.read_csv(ROOT/'correspondence_outputs/Inherited_Source_Artifact_Mapping.csv')\ndisplay(mapping[['artifact','source_rows','byte_identical_to_inherited_v2']].rename(columns={'artifact':'Inherited artifact','source_rows':'Rows','byte_identical_to_inherited_v2':'Byte identical'}))\nledger = pd.read_csv(ROOT/'correspondence_outputs/Source_Compatible_192_State_Ledger.csv')\ncomponents = ledger.groupby(['gene','P3_component']).agg(complete_rows=('state','count'),deviated_rows=('base_deviated_from_reference','sum')).reset_index()\ndisplay(components.rename(columns={'gene':'Gene','P3_component':'Full P2 component','complete_rows':'Complete rows','deviated_rows':'Differentiated rows'}))\nassert len(ledger)==192 and ledger.groupby(['gene','component_index']).size().eq(8).all()")
    md("### Shannon and identity together\n\nThe inherited wrong-state deterministic case retains zero Shannon entropy and fails reference identity. The full gate requires both criteria. These are the declared computational identity-alphabet counts.")
    code("shannon = pd.read_csv(ROOT/'correspondence_outputs/Corrected_Shannon_Identity_Replay.csv')\nlabels = {'scenario':'Source scenario','reference_checks':'Reference checks','disease_or_nonreference_checks':'Wrong-state checks','H_Shannon_bits_reference_vs_other':'Shannon bits','entropy_zero':'Zero entropy','all_200_reference_identity':'Reference identity','lawful_delay_closure':'Full Delay closure'}\nreadable = shannon.rename(columns=labels).copy()\nreadable['Shannon bits'] = readable['Shannon bits'].map(lambda x: '0.000000' if x==0 else format(x,'.6f'))\ndisplay(readable)\nomission = pd.read_csv(ROOT/'correspondence_outputs/Corrected_Omission_Frame_Replay.csv')\nprint('No-intervention weak/full acceptance counts:',{field:int(omission[field].sum()) for field in ['fold_only_accepts','MFE_only_accepts','fold_plus_MFE_accepts','corrected_full_gate_accepts']})")
    md("## Takeaways\n\nThe source and rerun measurements agree. The former acceptance gate did not enforce all supplied criteria; the corrected entry point does, and the source falsifier correspondence is explicit. Original law, source mathematics, results, and 40 native measurements are preserved.\n\nThe original four-arm cell/tissue-fold/organoid protocol and empty templates remain in the cancer packet. This notebook generates no biological data. It does not replace the research mathematics with software checks. See the Markdown report for the complete correction and file mapping.")
    nb = nbformat.v4.new_notebook(cells=cells, metadata={"kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"}, "language_info": {"name": "python"}})
    sys.path.insert(0, str(root / "rna_run"))
    from finalize_notebook import execute_cells
    execute_cells(nb)
    nb.metadata["execution"]["RNA_runs"] = "Source comparison and gate replay only; zero native RNA folds performed"
    path = root / "QTET_RNA_Source_Correspondence_20261008.ipynb"
    nbformat.validate(nb)
    nbformat.write(nb, path)
    candidates = [Path(sys.prefix)/"share/jupyter/nbconvert/templates",
                  root/"dependencies/share/jupyter/nbconvert/templates",
                  root.parents[1]/"rna_reversion_redo_20261008/dependencies/share/jupyter/nbconvert/templates"]
    template = next((p for p in candidates if (p/"lab").is_dir()), None)
    options = {"extra_template_basedirs": [str(template)], "extra_template_paths": [str(template)]} if template else {}
    html, _ = HTMLExporter(template_name="lab", **options).from_notebook_node(nb)
    html = re.sub(r'<script\b[^>]*\bsrc=["\']https?://[^"\']+["\'][^>]*>.*?</script>', "", html, flags=re.S | re.I)
    html = html.replace("</head>", "<style>.dataframe th,.dataframe td{padding:6px 10px;vertical-align:middle;white-space:normal;} .dataframe{max-width:100%;} </style></head>")
    preview = root / "QTET_RNA_Source_Correspondence_20261008.html"
    preview.write_text(html)
    print(path.name, preview.name)


if __name__ == "__main__":
    main()
