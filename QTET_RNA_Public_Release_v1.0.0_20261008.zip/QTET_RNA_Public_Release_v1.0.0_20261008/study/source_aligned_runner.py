"""Validate before inheriting RNA outputs and after any authorized engine run."""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

from source_aligned_closure import validate_lane
from verify_source_correspondence import reference_sequence

PRODUCER_SHA256 = "7454028a0467e0aef3ddab0fcbca9bb5e376069e0e75f1c1ccf52c07421dc27d"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--execute-missing", action="store_true",
                        help="Execute only missing originally authorized baseline lanes")
    args = parser.parse_args()
    root = args.root.resolve()
    run = root / "rna_run"
    producer = run / "coupled_rna_runner.py"
    if hashlib.sha256(producer.read_bytes()).hexdigest() != PRODUCER_SHA256:
        raise ValueError("Retained native measurement producer differs")
    rows = json.loads((run / "frozen_inputs/panel.json").read_text())
    results, missing = [], []
    for row in rows:
        path = run / "outputs" / (row["gene"] + "_37C.json")
        if not path.exists():
            missing.append(row["gene"])
            continue
        record = json.loads(path.read_text())
        if record["runner_sha256"] != PRODUCER_SHA256:
            raise ValueError("Native record producer provenance differs")
        results.append(validate_lane(record, reference_sequence(root, row), row))
    if missing:
        if not args.execute_missing:
            raise ValueError("Missing lanes: " + ", ".join(missing))
        subprocess.run([sys.executable, str(producer), "--root", str(run), "--workers", "3", "--genes", *missing], check=True)
        for row in rows:
            if row["gene"] in missing:
                record = json.loads((run / "outputs" / (row["gene"] + "_37C.json")).read_text())
                results.append(validate_lane(record, reference_sequence(root, row), row))
    out = root / "correspondence_outputs"
    out.mkdir(exist_ok=True)
    (out / "Runner_Acceptance.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps({"accepted_lanes": len(results), "all_disclosed_source_closure_criteria_pass": all(r["closure_pass"] for r in results),
                      "fresh_engine_execution_requested": args.execute_missing, "newly_executed_lanes": len(missing)}, indent=2))


if __name__ == "__main__":
    main()
